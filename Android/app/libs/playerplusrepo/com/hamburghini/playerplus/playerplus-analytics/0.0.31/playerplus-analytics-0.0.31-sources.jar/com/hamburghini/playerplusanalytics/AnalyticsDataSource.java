package com.hamburghini.playerplusanalytics;

import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.datasource.TransferListener;

import java.util.List;
import java.util.Map;

@UnstableApi
public class AnalyticsDataSource implements HttpDataSource {

    private final HttpDataSource upstream;
    private final OnHeadersReceivedListener onHeadersReceived;

    public AnalyticsDataSource(HttpDataSource upstream,
                               OnHeadersReceivedListener onHeadersReceived) {
        this.upstream = upstream;
        this.onHeadersReceived = onHeadersReceived;
    }

    @Override
    public long open(@NonNull DataSpec dataSpec) throws HttpDataSourceException {
        long bytesOpened = upstream.open(dataSpec);

        Map<String, List<String>> responseHeaders = upstream.getResponseHeaders();
        onHeadersReceived.onHeadersReceived(dataSpec.uri, responseHeaders);

        return bytesOpened;
    }

    @Override
    public void close() throws HttpDataSourceException {
        upstream.close();
    }

    @Override
    public int read(@NonNull byte[] buffer, int offset, int readLength) throws HttpDataSourceException {
        return upstream.read(buffer, offset, readLength);
    }

    @Override
    public Uri getUri() {
        return upstream.getUri();
    }

    @NonNull
    @Override
    public Map<String, List<String>> getResponseHeaders() {
        return upstream.getResponseHeaders();
    }

    @Override
    public void setRequestProperty(@NonNull String name, @NonNull String value) {
        upstream.setRequestProperty(name, value);
    }

    @Override
    public void clearRequestProperty(@NonNull String name) {
        upstream.clearRequestProperty(name);
    }

    @Override
    public void clearAllRequestProperties() {
        upstream.clearAllRequestProperties();
    }

    @Override
    public int getResponseCode() {
        return upstream.getResponseCode();
    }

    @Override
    public void addTransferListener(@NonNull TransferListener transferListener) {
        upstream.addTransferListener(transferListener);
    }
}
