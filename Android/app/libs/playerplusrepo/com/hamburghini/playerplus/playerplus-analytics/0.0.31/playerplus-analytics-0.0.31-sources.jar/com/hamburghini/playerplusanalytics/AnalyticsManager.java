package com.hamburghini.playerplusanalytics;

import android.content.Context;
import android.os.Build;

import androidx.media3.common.PlaybackException;
import androidx.media3.common.VideoSize;
import androidx.media3.datasource.HttpDataSource;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.player.PlayerController;
import com.hamburghini.playerplusanalytics.model.CDNInfo;
import com.hamburghini.playerplusanalytics.model.CollectorConfig;
import com.hamburghini.playerplusanalytics.model.UserInfo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.logs.Logger;
import io.opentelemetry.api.logs.Severity;
import io.opentelemetry.api.metrics.DoubleHistogram;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.logs.SdkLoggerProvider;
import io.opentelemetry.sdk.logs.export.BatchLogRecordProcessor;
import io.opentelemetry.sdk.metrics.SdkMeterProvider;
import io.opentelemetry.sdk.metrics.export.PeriodicMetricReader;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.semconv.resource.attributes.ResourceAttributes;

public class AnalyticsManager {

    private static AnalyticsManager instance;
    private static final String X_CACHE = "X-Cache";
    private static final String X_POP = "X-Amz-Cf-Pop";

    private final CollectorConfig config;
    private OpenTelemetry openTelemetry;
    private Logger logger;
    private Meter meter;
    private SdkLoggerProvider loggerProvider;
    private SdkMeterProvider meterProvider;

    // Common metrics
    private LongCounter videoStartCounter;
    private LongCounter videoCompleteCounter;
    private LongCounter videoErrorCounter;
    private LongCounter bufferingCounter;
    private DoubleHistogram videoDurationHistogram;
    private DoubleHistogram bufferingDurationHistogram;
    private LongCounter cdnRequestCounter;
    private LongCounter cdnCacheHitCounter;
    private LongCounter cdnCacheMissCounter;

    private boolean isInitialized = false;
    private UserInfo userInfo = null;

    private AnalyticsManager(CollectorConfig config) {
        this.config = config;
    }

    public static synchronized AnalyticsManager getInstance() {
        if (instance == null) {
            throw new IllegalStateException("AnalyticsManager not initialized. Call getInstance(config) first.");
        }
        return instance;
    }

    public static void initialize(Context context) {
        initialize(context, null);
    }

    public static void initialize(Context context, CollectorConfig collectorConfig) {
        if (instance != null) {
            SDKLogger.w("AnalyticsManager already initialized");
            return;
        }

        instance = new AnalyticsManager(collectorConfig);
        instance.setup(context);
    }

    private void setup(Context context) {
        try {
            if (config != null) {
                // Create resource with service information
                Resource resource = Resource.getDefault()
                        .merge(Resource.builder()
                                .put(ResourceAttributes.SERVICE_NAME, "android-video-analytics")
                                .put(ResourceAttributes.SERVICE_VERSION, "1.0.0")
                                .put("app.name", context.getPackageName())
                                .build());

                // Initialize Logs
                VictoriaLogsExporter logsExporter = new VictoriaLogsExporter(
                        config.getLogsEndpoint()
                );
                SDKLogger.i(config.getLogsEndpoint());

                loggerProvider = SdkLoggerProvider.builder()
                        .setResource(resource)
                        .addLogRecordProcessor(BatchLogRecordProcessor.builder(logsExporter).build())
                        .build();

                // Initialize Metrics
                VictoriaMetricsExporter metricsExporter = new VictoriaMetricsExporter(
                        config.getMetricsEndpoint()
                );

                meterProvider = SdkMeterProvider.builder()
                        .setResource(resource)
                        .registerMetricReader(
                                PeriodicMetricReader.builder(metricsExporter)
                                        .setInterval(java.time.Duration.ofSeconds(30))
                                        .build()
                        )
                        .build();

                // Build OpenTelemetry SDK
                openTelemetry = OpenTelemetrySdk.builder()
                        .setLoggerProvider(loggerProvider)
                        .setMeterProvider(meterProvider)
                        .build();

                // Get logger and meter instances
                logger = openTelemetry.getLogsBridge()
                        .loggerBuilder("com.hamburghini.playerplusanalytics")
                        .build();

                meter = openTelemetry.getMeter("com.hamburghini.playerplusanalytics");

                // Initialize common metrics
                initializeMetrics();
            }

            fetchUserInfo();

            isInitialized = true;

            // Send initialization log
            logInfo("AnalyticsManager initialized successfully");

            SDKLogger.i("AnalyticsManager initialized");

        } catch (Exception e) {
            SDKLogger.e("Failed to initialize AnalyticsManager", e);
        }
    }

    private void initializeMetrics() {
        videoStartCounter = meter.counterBuilder("video.started")
                .setDescription("Number of video playback starts")
                .build();

        videoCompleteCounter = meter.counterBuilder("video.completed")
                .setDescription("Number of video playback completions")
                .build();

        videoErrorCounter = meter.counterBuilder("video.errors")
                .setDescription("Number of video playback errors")
                .build();

        bufferingCounter = meter.counterBuilder("video.buffering.events")
                .setDescription("Number of buffering events")
                .build();

        videoDurationHistogram = meter.histogramBuilder("video.duration")
                .setDescription("Video playback duration in seconds")
                .setUnit("s")
                .build();

        bufferingDurationHistogram = meter.histogramBuilder("video.buffering.duration")
                .setDescription("Buffering duration in milliseconds")
                .setUnit("ms")
                .build();

        cdnRequestCounter = meter.counterBuilder("cdn.requests_total")
                .setDescription("Total CDN requests")
                .setUnit("1")
                .build();

        cdnCacheHitCounter = meter.counterBuilder("cdn.cache_hits")
                .setDescription("CDN cache hits")
                .setUnit("1")
                .build();

        cdnCacheMissCounter = meter.counterBuilder("cdn.cache_misses")
                .setDescription("CDN cache misses")
                .setUnit("1")
                .build();
    }

    // ===== Logging Methods =====

    public void log(Severity severity, String message, Map<String, String> attributes) {
        if (!isInitialized) return;

        try {
            var builder = logger.logRecordBuilder()
                    .setSeverity(severity)
                    .setBody(message);

            if (attributes != null) {
                for (Map.Entry<String, String> entry : attributes.entrySet()) {
                    builder.setAttribute(AttributeKey.stringKey(entry.getKey()), entry.getValue());
                }
            }

            builder.emit();
        } catch (Exception e) {
            SDKLogger.e("Failed to send log", e);
        }
    }

    public void logInfo(String message) {
        log(Severity.INFO, message, null);
    }

    public void logInfo(String message, Map<String, String> attributes) {
        log(Severity.INFO, message, attributes);
    }

    public void logDebug(String message) {
        log(Severity.DEBUG, message, null);
    }

    public void logDebug(String message, Map<String, String> attributes) {
        log(Severity.DEBUG, message, attributes);
    }

    public void logWarning(String message) {
        log(Severity.WARN, message, null);
    }

    public void logWarning(String message, Map<String, String> attributes) {
        log(Severity.WARN, message, attributes);
    }

    public void logError(String message, String errorType) {
        log(Severity.ERROR, message, null);
    }

    public void logError(String message, String errorType, Map<String, String> attributes) {
        log(Severity.ERROR, message, attributes);
    }

    // ===== Video Event Methods =====

    public void trackVideoStart(String videoId, String videoUrl) {
        if (!isInitialized) return;

        Map<String, String> attrs = new HashMap<>();
        attrs.put("video.id", videoId);
        attrs.put("video.url", videoUrl);
        attrs.put("event.type", "video_start");

        logInfo("Video playback started", attrs);

        Attributes metricAttrs = Attributes.builder()
                .put("video.id", videoId)
                .build();
        videoStartCounter.add(1, metricAttrs);
    }

    public void trackVideoComplete(String videoId, double durationSeconds) {
        if (!isInitialized) return;

        Map<String, String> attrs = new HashMap<>();
        attrs.put("video.id", videoId);
        attrs.put("duration", String.valueOf(durationSeconds));
        attrs.put("event.type", "video_complete");

        logInfo("Video playback completed", attrs);

        Attributes metricAttrs = Attributes.builder()
                .put("video.id", videoId)
                .build();
        videoCompleteCounter.add(1, metricAttrs);
        videoDurationHistogram.record(durationSeconds, metricAttrs);
    }

    public void trackVideoError(String videoId, String errorType, String errorMessage) {
        if (!isInitialized) return;

        Map<String, String> attrs = new HashMap<>();
        attrs.put("video.id", videoId);
        attrs.put("error.message", errorMessage);
        attrs.put("event.type", "video_error");

        logError("Video playback error", errorType, attrs);

        Attributes metricAttrs = Attributes.builder()
                .put("video.id", videoId)
                .put("error.type", errorType)
                .build();
        videoErrorCounter.add(1, metricAttrs);
    }

    public void trackBufferingStart(String videoId) {
        if (!isInitialized) return;

        Map<String, String> attrs = new HashMap<>();
        attrs.put("video.id", videoId);
        attrs.put("event.type", "buffering_start");

        logInfo("Buffering started", attrs);
    }

    public void trackBufferingEnd(String videoId, long durationMs) {
        if (!isInitialized) return;

        Map<String, String> attrs = new HashMap<>();
        attrs.put("video.id", videoId);
        attrs.put("duration_ms", String.valueOf(durationMs));
        attrs.put("event.type", "buffering_end");

        logInfo("Buffering ended", attrs);

        Attributes metricAttrs = Attributes.builder()
                .put("video.id", videoId)
                .build();
        bufferingCounter.add(1, metricAttrs);
        bufferingDurationHistogram.record(durationMs, metricAttrs);
    }

    public void trackQualityChange(String videoId, String fromQuality, String toQuality) {
        if (!isInitialized) return;

        Map<String, String> attrs = new HashMap<>();
        attrs.put("video.id", videoId);
        attrs.put("quality.from", fromQuality);
        attrs.put("quality.to", toQuality);
        attrs.put("event.type", "quality_change");

        logInfo("Video quality changed", attrs);
    }

    public void trackSeek(String videoId, long fromPositionMs, long toPositionMs) {
        if (!isInitialized) return;

        Map<String, String> attrs = new HashMap<>();
        attrs.put("video.id", videoId);
        attrs.put("seek.from", String.valueOf(fromPositionMs));
        attrs.put("seek.to", String.valueOf(toPositionMs));
        attrs.put("event.type", "seek");

        logInfo("User seeked in video", attrs);
    }

    // ===== Custom Metrics =====

    public LongCounter createCounter(String name, String description) {
        if (!isInitialized) return null;
        return meter.counterBuilder(name)
                .setDescription(description)
                .build();
    }

    public DoubleHistogram createHistogram(String name, String description, String unit) {
        if (!isInitialized) return null;
        return meter.histogramBuilder(name)
                .setDescription(description)
                .setUnit(unit)
                .build();
    }

    // ===== Shutdown =====

    public void shutdown() {
        if (!isInitialized) return;

        try {
            logInfo("AnalyticsManager shutting down");

            if (loggerProvider != null) {
                loggerProvider.close();
            }

            if (meterProvider != null) {
                meterProvider.close();
            }

            isInitialized = false;
            SDKLogger.i("AnalyticsManager shutdown complete");

        } catch (Exception e) {
            SDKLogger.e("Error during AnalyticsManager shutdown", e);
        }
    }

    public boolean isInitialized() {
        return isInitialized;
    }

    public void fetchUserInfo() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL("https://pro.ip-api.com/json/?key=AmUN9xAaQALVYu6");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                SDKLogger.d("response code: " + conn.getResponseCode());
                BufferedReader reader =
                        new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                SDKLogger.i("user info: " + response);
                JsonObject json = JsonParser.parseString(response.toString()).getAsJsonObject();

                userInfo = new UserInfo(
                        json.get("query").getAsString(),
                        json.get("city").getAsString(),
                        json.get("regionName").getAsString(),
                        json.get("country").getAsString(),
                        json.get("countryCode").getAsString(),
                        json.get("isp").getAsString(),
                        json.get("timezone").getAsString(),
                        json.get("zip").getAsString(),
                        json.get("lat").getAsDouble(),
                        json.get("lon").getAsDouble()
                );
            } catch (Exception e) {
                SDKLogger.e("fetchUserInfo error", e);
            }
        });
    }

    public void onStateChanged(PlayerController.State state) {
        Map<String, String> map = new HashMap<>();
        map.put("state", state.name());
        logInfo("Playback state changed", map);
    }

    public void onIsPlayingChanged(boolean isPlaying) {

    }

    public void onVideoSizeChanged(VideoSize videoSize) {

    }

    public void onPlayerError(PlaybackException e) {

    }

    public void onPositionChanged(long oldPositionMs, long newPositionMs) {

    }

    public HttpDataSource.Factory createDataSourceFactory() {
        OnHeadersReceivedListener listener = (uri, headers) -> {
            String cacheHeaderResponse = null;
            List<String> cacheList = headers.get(X_CACHE);
            if (cacheList != null && !cacheList.isEmpty()) {
                cacheHeaderResponse = cacheList.get(0);
            }

            String popHeaderResponse = null;
            List<String> popList = headers.get(X_POP);
            if (popList != null && !popList.isEmpty()) {
                popHeaderResponse = popList.get(0);
            }

            String cacheStatus;
            if (cacheHeaderResponse == null) {
                cacheStatus = "UNKNOWN";
            } else if (cacheHeaderResponse.toLowerCase().contains("hit")) {
                cacheStatus = "HIT";
            } else if (cacheHeaderResponse.toLowerCase().contains("miss")) {
                cacheStatus = "MISS";
            } else {
                cacheStatus = "UNKNOWN";
            }

            String pop = (popHeaderResponse != null) ? popHeaderResponse : "UNKNOWN";

            SDKLogger.i("URI: " + uri);
            SDKLogger.i("X-Cache: " + cacheStatus);
            SDKLogger.i("X-Amz-Cf-Pop: " + pop);
        };
        return new AnalyticsDataSourceFactory(listener);
    }

    public void processCDNHeaders(
            String videoId,
            String uri,
            String cacheStatus,
            String pop
    ) {
        CDNInfo cdnInfo = new CDNInfo(uri, cacheStatus, pop);

//        // Add to cdnTrackingData
//        List<CDNInfo> list = cdnTrackingData.get(videoId);
//        if (list != null) {
//            list.add(cdnInfo);
//        }

        // Build metric attributes
        Attributes metricAttrs = Attributes.builder()
                .put("video_id", videoId)
                .put("cdn.provider", cdnInfo.getProvider())
                .put("cdn.pop", pop)
                .put("cdn.location", cdnInfo.getLocation())
                .put("cdn.cache_status", cacheStatus)
                .put("cdn.uri", uri)
                .put("session_id", "sessionId")
                .put("user.city", userInfo != null ? userInfo.getCity() : "Unknown")
                .put("user.country", userInfo != null ? userInfo.getCountry() : "Unknown")
                .put("user.isp", userInfo != null ? userInfo.getIsp() : "Unknown")
                .build();

        // Metrics counters
        cdnRequestCounter.add(1, metricAttrs);

        switch (cacheStatus) {
            case "HIT":
                cdnCacheHitCounter.add(1, metricAttrs);
                break;
            case "MISS":
                cdnCacheMissCounter.add(1, metricAttrs);
                break;
        }

        // SDK Logger output
        SDKLogger.i("🌐 CDN REQUEST TRACKED");
        SDKLogger.i("├─ Video ID: " + videoId);
        SDKLogger.i("├─ URI: " + uri);
        SDKLogger.i("├─ Cache Status: " + cacheStatus);
        SDKLogger.i("├─ POP: " + pop);
        SDKLogger.i("├─ Provider: " + cdnInfo.getProvider());
        SDKLogger.i("└─ Location: " + cdnInfo.getLocation());

        // Send log
        Map<String, String> attributes = new HashMap<>();
        attributes.put("video_id", videoId);
        attributes.put("uri", uri);
        attributes.put("cache_status", cacheStatus);
        attributes.put("cdn_provider", cdnInfo.getProvider());
        attributes.put("pop", pop);
        attributes.put("location", cdnInfo.getLocation());
        attributes.put("session_id", "sessionId");

        logDebug("CDN request processed", attributes);

        logMetricSent("cdn.requests_total", 1, metricAttrs);
    }

    private void logMetricSent(String metricName, long value, Attributes attributes) {
        SDKLogger.d("📤 METRIC SENT: " + metricName);
        SDKLogger.d("   Value: " + value);
        SDKLogger.d("   Attributes: {");

        attributes.forEach((key, val) -> {
            SDKLogger.d("     " + key.getKey() + ": " + val);
        });

        SDKLogger.d("   }");
    }

    public Map<String, String> getUserInfo() {
        Map<String, String> info = new HashMap<>();
        if (userInfo != null) {
            info.put("ip", userInfo.getIp());
            info.put("X-Geo-City", userInfo.getCity());
            info.put("region", userInfo.getRegion());
            info.put("X-Geo-Country", userInfo.getCountry());
            info.put("countryCode", userInfo.getCountryCode());
            info.put("X-ISP", userInfo.getIsp());
            info.put("timezone", userInfo.getTimezone());
            info.put("zip", userInfo.getZip());
            info.put("lat", String.valueOf(userInfo.getLat()));
            info.put("lon", String.valueOf(userInfo.getLon()));
            info.put("x-device-model", Build.MODEL);
            info.put("deviceManufacturer", Build.MANUFACTURER);
            info.put("x-device-brand", Build.BRAND);
            info.put("androidVersion", Build.VERSION.RELEASE);
        }
        return info;
    }

}