package com.hamburghini.playerplusanalytics.model;

import java.util.Map;

public class CDNInfo {

    private final String uri;
    private final String cacheStatus;
    private final String pop;

    public CDNInfo(String uri, String cacheStatus, String pop) {
        this.uri = uri;
        this.cacheStatus = cacheStatus;
        this.pop = pop;
    }

    public String getUri() {
        return uri;
    }

    public String getCacheStatus() {
        return cacheStatus;
    }

    public String getPop() {
        return pop;
    }

    // Equivalent to Kotlin's computed property "provider"
    public String getProvider() {
        String p = pop != null ? pop : "";

        if (p.toLowerCase().contains("deploy.static.akamaitechnologies.com")) return "Akamai";
        if (p.toLowerCase().contains("deploy.akamaitechnologies.com")) return "Akamai";

        if (p.matches("(?i)[A-Z]{3}\\d+-[PC]\\d+")) return "CloudFront";

        if (p.toLowerCase().contains("cloudflare")) return "Cloudflare";
        if (p.toLowerCase().contains("fastly")) return "Fastly";
        if (p.toLowerCase().contains("castis")) return "Castis";

        if ("UNKNOWN".equalsIgnoreCase(p)) return "Unknown";

        return "Other";
    }

    // Equivalent to Kotlin's computed property "location"
    public String getLocation() {
        String p = pop != null ? pop : "";

        if (p.length() >= 3 && p.matches("(?i)[A-Z]{3}.*")) {
            String code = p.substring(0, 3).toUpperCase();
            return CDN_LOCATION_MAP.getOrDefault(code, code);
        }

        return "Unknown";
    }

    // Companion object equivalent
    private static final Map<String, String> CDN_LOCATION_MAP = Map.ofEntries(
            Map.entry("ICN", "Seoul"),
            Map.entry("NRT", "Tokyo"),
            Map.entry("SIN", "Singapore"),
            Map.entry("HKG", "Hong Kong"),
            Map.entry("SYD", "Sydney"),
            Map.entry("LAX", "Los Angeles"),
            Map.entry("SFO", "San Francisco"),
            Map.entry("JFK", "New York"),
            Map.entry("IAD", "Washington DC"),
            Map.entry("LHR", "London"),
            Map.entry("FRA", "Frankfurt"),
            Map.entry("CDG", "Paris"),
            Map.entry("AMS", "Amsterdam")
    );
}
