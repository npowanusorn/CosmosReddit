package com.hamburghini.playerplusanalytics;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.analytics.AnalyticsListener;

import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.capabilities.AnalyticsCapability;
import com.hamburghini.playerplus.capabilities.CdnTrackingCapability;
import com.hamburghini.playerplus.capabilities.UserInfoTrackingCapability;
import com.hamburghini.playerplus.player.PlayerController;
import com.hamburghini.playerplus.plugin.Plugin;
import com.hamburghini.playerplusanalytics.model.AnalyticsConfig;
import com.hamburghini.playerplusanalytics.model.CollectorConfig;

import java.util.Map;

public class AnalyticsPlugin implements Plugin, AnalyticsCapability, CdnTrackingCapability, UserInfoTrackingCapability {

    private final AnalyticsConfig config;
    private AnalyticsManager analyticsManager;

    public AnalyticsPlugin(AnalyticsConfig config) {
        this.config = config;
    }

    @Override
    public void onRegister(Context context) {
        SDKLogger.d("AnalyticsPlugin onRegister");

        try {
            // Initialize analytics manager
            AnalyticsManager.initialize(context);
            analyticsManager = AnalyticsManager.getInstance();

            // Send registration log
            analyticsManager.logInfo("AnalyticsPlugin registered successfully");

            SDKLogger.i("AnalyticsPlugin registered");

        } catch (Exception e) {
            SDKLogger.e("Failed to register AnalyticsPlugin", e);
        }
    }

    @Override
    public void onUnregister() {
        SDKLogger.d("AnalyticsPlugin onUnregister");

        if (analyticsManager != null) {
            analyticsManager.logInfo("AnalyticsPlugin unregistering");
            analyticsManager.shutdown();
        }
    }

    @Override
    public String getName() {
        return "AnalyticsPlugin";
    }

    // ===== PlayerEventListener Implementation =====

    @OptIn(markerClass = UnstableApi.class)
    @Override
    public AnalyticsListener getAnalyticsListener() {
        return new AnalyticsListener() {
            @Override
            public void onPlaybackStateChanged(@NonNull EventTime eventTime, int state) {
                analyticsManager.onStateChanged(PlayerController.State.get(state));
            }

            @Override
            public void onIsPlayingChanged(@NonNull EventTime eventTime, boolean isPlaying) {
                analyticsManager.onIsPlayingChanged(isPlaying);
            }

            @Override
            public void onVideoSizeChanged(@NonNull EventTime eventTime, @NonNull VideoSize videoSize) {
                analyticsManager.onVideoSizeChanged(videoSize);
            }

            @Override
            public void onPlayerError(@NonNull EventTime eventTime, @NonNull PlaybackException error) {
                analyticsManager.onPlayerError(error);
            }

            @Override
            public void onPositionDiscontinuity(@NonNull EventTime eventTime, @NonNull Player.PositionInfo oldPosition, @NonNull Player.PositionInfo newPosition, int reason) {
                analyticsManager.onPositionChanged(oldPosition.positionMs, newPosition.positionMs);
            }
        };
    }

    @Override
    public HttpDataSource.Factory createDataSourceFactory() {
        SDKLogger.d("analyticsManager is null: " + (analyticsManager == null));
        return analyticsManager.createDataSourceFactory();
    }

    @Override
    public Map<String, String> getUserInfo() {
        return analyticsManager.getUserInfo();
    }
}
