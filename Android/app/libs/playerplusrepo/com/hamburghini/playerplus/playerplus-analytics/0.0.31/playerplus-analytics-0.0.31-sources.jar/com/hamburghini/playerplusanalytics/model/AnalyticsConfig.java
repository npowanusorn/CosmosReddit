package com.hamburghini.playerplusanalytics.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AnalyticsConfig {
    private final Boolean enableCmcd;
    private final Boolean enableHeaderAnalytics;
    private final CollectorConfig collectorConfig;

    public AnalyticsConfig(
            @NonNull Boolean enableCmcd,
            @NonNull Boolean enableHeaderAnalytics,
            @Nullable CollectorConfig collectorConfig
    ) {
        this.enableCmcd = enableCmcd;
        this.enableHeaderAnalytics = enableHeaderAnalytics;
        this.collectorConfig = collectorConfig;
    }

    public Boolean getEnableCmcd() {
        return enableCmcd;
    }

    public Boolean getEnableHeaderAnalytics() {
        return enableHeaderAnalytics;
    }

    public CollectorConfig getCollectorConfig() {
        return collectorConfig;
    }
}
