package com.hamburghini.playerplusanalytics;

import androidx.annotation.NonNull;

import com.hamburghini.playerplus.SDKLogger;

import java.util.Collection;

import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.metrics.InstrumentType;
import io.opentelemetry.sdk.metrics.data.AggregationTemporality;
import io.opentelemetry.sdk.metrics.data.MetricData;
import io.opentelemetry.sdk.metrics.export.MetricExporter;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class VictoriaMetricsExporter implements MetricExporter {
    private final String endpoint;
    private final OkHttpClient client = new OkHttpClient();

    public VictoriaMetricsExporter(String endpoint) {
        this.endpoint = endpoint; // http://host:8428/api/v1/import/prometheus
    }

    @Override
    public CompletableResultCode export(@NonNull Collection<MetricData> metrics) {
        try {
            StringBuilder bodyText = new StringBuilder();

            for (MetricData metric : metrics) {
                metric.getDoubleSumData().getPoints().forEach(p -> {
                    bodyText.append(metric.getName())
                            .append("{source=\"android_app\"}")
                            .append(" ")
                            .append(p.getValue())
                            .append("\n");
                });
            }

            RequestBody body = RequestBody.create(
                    bodyText.toString(),
                    MediaType.parse("text/plain")
            );

            Request req = new Request.Builder()
                    .url(endpoint)
                    .post(body)
                    .build();

            client.newCall(req).execute().close();

            return CompletableResultCode.ofSuccess();
        } catch (Exception e) {
            SDKLogger.e("export error", e);
            return CompletableResultCode.ofFailure();
        }
    }

    @Override
    public CompletableResultCode flush() {
        return CompletableResultCode.ofSuccess();
    }

    @Override
    public CompletableResultCode shutdown() {
        return CompletableResultCode.ofSuccess();
    }

    @Override
    public AggregationTemporality getAggregationTemporality(@NonNull InstrumentType instrumentType) {
        return null;
    }
}
