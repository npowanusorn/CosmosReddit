package com.hamburghini.playerplusanalytics.model;

import java.util.Collections;
import java.util.Map;

public class CollectorConfig {

    private final String collectorHost;
    private final String collectorProtocol;
    private final Integer tracesPort;
    private final Integer metricsPort;
    private final Integer logsPort;
    private final String tracesPath;
    private final String metricsPath;
    private final String logsPath;
    private final String serviceName;
    private final String appName;
    private final String appVersion;
    private final String environment;
    private final long heartbeat;
    private final AuthType authType;
    private final String authToken;
    private final String authUsername;
    private final String authPassword;
    private final Map<String, String> customHeaders;

    private CollectorConfig(Builder builder) {
        this.collectorHost = builder.collectorHost;
        this.collectorProtocol = builder.collectorProtocol;
        this.tracesPort = builder.tracesPort;
        this.metricsPort = builder.metricsPort;
        this.logsPort = builder.logsPort;
        this.tracesPath = builder.tracesPath;
        this.metricsPath = builder.metricsPath;
        this.logsPath = builder.logsPath;
        this.serviceName = builder.serviceName;
        this.appName = builder.appName;
        this.appVersion = builder.appVersion;
        this.environment = builder.environment;
        this.heartbeat = builder.heartbeat;
        this.authType = builder.authType;
        this.authToken = builder.authToken;
        this.authUsername = builder.authUsername;
        this.authPassword = builder.authPassword;
        this.customHeaders = builder.customHeaders != null
                ? Collections.unmodifiableMap(builder.customHeaders)
                : Collections.emptyMap();
    }

    // ===== Computed Endpoints =====

    public String getTracesEndpoint() {
        if (tracesPort == null) {
            return collectorProtocol + "://" + collectorHost + tracesPath;
        }
        return collectorProtocol + "://" + collectorHost + ":" + tracesPort + tracesPath;
    }

    public String getMetricsEndpoint() {
        if (metricsPort == null) {
            return collectorProtocol + "://" + collectorHost + metricsPath;
        }
        return collectorProtocol + "://" + collectorHost + ":" + metricsPort + metricsPath;
    }

    public String getLogsEndpoint() {
        if (logsPort == null) {
            return collectorProtocol + "://" + collectorHost + logsPath;
        }
        return collectorProtocol + "://" + collectorHost + ":" + logsPort + logsPath;
    }

    // ===== Builder =====

    public static class Builder {

        private String collectorHost;
        private String collectorProtocol;

        private Integer tracesPort = null;
        private Integer metricsPort = null;
        private Integer logsPort = null;

        private String tracesPath = "/v1/traces";
        private String metricsPath = "/v1/metrics";
        private String logsPath = "/v1/logs";

        private String serviceName = "android-video-telemetry";
        private String appName = "AndroidTV";
        private String appVersion = "1.0.0";
        private String environment = "production";
        private long heartbeat = 30_000;

        private AuthType authType = AuthType.NONE;
        private String authToken = null;
        private String authUsername = null;
        private String authPassword = null;

        private Map<String, String> customHeaders = Collections.emptyMap();

        // Required parameters
        public Builder(String collectorHost, String collectorProtocol) {
            this.collectorHost = collectorHost;
            this.collectorProtocol = collectorProtocol;
        }

        public Builder tracesPort(Integer val) { this.tracesPort = val; return this; }
        public Builder metricsPort(Integer val) { this.metricsPort = val; return this; }
        public Builder logsPort(Integer val) { this.logsPort = val; return this; }

        public Builder tracesPath(String val) { this.tracesPath = val; return this; }
        public Builder metricsPath(String val) { this.metricsPath = val; return this; }
        public Builder logsPath(String val) { this.logsPath = val; return this; }

        public Builder serviceName(String val) { this.serviceName = val; return this; }
        public Builder appName(String val) { this.appName = val; return this; }
        public Builder appVersion(String val) { this.appVersion = val; return this; }
        public Builder environment(String val) { this.environment = val; return this; }
        public Builder heartbeat(long val) { this.heartbeat = val; return this; }

        public Builder authType(AuthType val) { this.authType = val; return this; }
        public Builder authToken(String val) { this.authToken = val; return this; }
        public Builder authUsername(String val) { this.authUsername = val; return this; }
        public Builder authPassword(String val) { this.authPassword = val; return this; }

        public Builder customHeaders(Map<String, String> val) {
            this.customHeaders = val;
            return this;
        }

        public CollectorConfig build() {
            return new CollectorConfig(this);
        }
    }

    public enum AuthType {
        NONE,
        BEARER_TOKEN,
        BASIC_AUTH,
        API_KEY,
        CUSTOM_HEADER
    }
}
