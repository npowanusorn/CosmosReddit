package com.hamburghini.playerplusanalytics;

import com.hamburghini.playerplus.SDKLogger;

import org.json.JSONObject;

import java.util.Collection;

import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.logs.data.LogRecordData;
import io.opentelemetry.sdk.logs.export.LogRecordExporter;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class VictoriaLogsExporter implements LogRecordExporter {
    private final String endpoint;
    private final OkHttpClient client = new OkHttpClient();

    public VictoriaLogsExporter(String endpoint) {
        this.endpoint = endpoint;
    }

    @Override
    public CompletableResultCode export(Collection<LogRecordData> logs) {
        for (LogRecordData log : logs) {
            try {
                JSONObject json = new JSONObject();
                json.put("message", log.getBody().asString());
                json.put("level", log.getSeverity().name());
                json.put("service", "android_app");

                RequestBody body = RequestBody.create(
                        json.toString(),
                        MediaType.parse("application/json")
                );

                Request req = new Request.Builder()
                        .url(endpoint)
                        .post(body)
                        .build();

                client.newCall(req).execute().close();
            } catch (Exception e) {
                SDKLogger.e("export error", e);
                return CompletableResultCode.ofFailure();
            }
        }
        return CompletableResultCode.ofSuccess();
    }

    @Override
    public CompletableResultCode flush() {
        return CompletableResultCode.ofSuccess();
    }

    @Override
    public CompletableResultCode shutdown() {
        return CompletableResultCode.ofSuccess();
    }
}
