package com.hamburghini.playerplusanalytics;

import android.net.Uri;

import java.util.List;
import java.util.Map;

public interface OnHeadersReceivedListener {
    void onHeadersReceived(Uri uri, Map<String, List<String>> headers);
}