package com.hamburghini.playerplusanalytics.model;

public class UserInfo {
    private final String ip;
    private final String city;
    private final String region;
    private final String country;
    private final String countryCode;
    private final String isp;
    private final String timezone;
    private final String zip;
    private final double lat;
    private final double lon;

    public UserInfo(
            String ip,
            String city,
            String region,
            String country,
            String countryCode,
            String isp,
            String timezone,
            String zip,
            double lat,
            double lon
    ) {
        this.ip = ip;
        this.city = city;
        this.region = region;
        this.country = country;
        this.countryCode = countryCode;
        this.isp = isp;
        this.timezone = timezone;
        this.zip = zip;
        this.lat = lat;
        this.lon = lon;
    }

    public String getIp() {
        return ip;
    }

    public String getCity() {
        return city;
    }

    public String getRegion() {
        return region;
    }

    public String getCountry() {
        return country;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public String getIsp() {
        return isp;
    }

    public String getTimezone() {
        return timezone;
    }

    public String getZip() {
        return zip;
    }

    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }
}
