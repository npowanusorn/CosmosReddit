package com.hamburghini.playerplusanalytics;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.HttpDataSource;

import java.util.Map;

public class AnalyticsDataSourceFactory implements HttpDataSource.Factory {

    private final OnHeadersReceivedListener onHeadersReceived;
    private final HttpDataSource.Factory upstreamFactory;

    @OptIn(markerClass = UnstableApi.class)
    public AnalyticsDataSourceFactory(OnHeadersReceivedListener onHeadersReceived) {
        this.onHeadersReceived = onHeadersReceived;

        this.upstreamFactory = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(DefaultHttpDataSource.DEFAULT_CONNECT_TIMEOUT_MILLIS)
                .setReadTimeoutMs(DefaultHttpDataSource.DEFAULT_READ_TIMEOUT_MILLIS);
    }

    @NonNull
    @OptIn(markerClass = UnstableApi.class)
    @Override
    public HttpDataSource createDataSource() {
        HttpDataSource upstream = upstreamFactory.createDataSource();
        return new AnalyticsDataSource(upstream, onHeadersReceived);
    }

    @OptIn(markerClass = UnstableApi.class)
    @NonNull
    @Override
    public HttpDataSource.Factory setDefaultRequestProperties(@NonNull Map<String, String> defaultRequestProperties) {
        upstreamFactory.setDefaultRequestProperties(defaultRequestProperties);
        return this;
    }
}
