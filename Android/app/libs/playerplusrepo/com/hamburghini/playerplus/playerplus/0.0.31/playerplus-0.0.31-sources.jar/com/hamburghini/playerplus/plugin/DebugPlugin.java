package com.hamburghini.playerplus.plugin;

import android.content.Context;

import com.hamburghini.playerplus.SDKLogger;

public class DebugPlugin implements Plugin {
    @Override
    public void onRegister(Context context) {
        SDKLogger.setEnabled(true);
        SDKLogger.i("Debug logging enabled");
    }

    @Override
    public void onUnregister() {
        SDKLogger.setEnabled(false);
        SDKLogger.i("Debug logging disabled via DebugPlugin");
    }

    @Override
    public String getName() {
        return "DebugPlugin";
    }
}
