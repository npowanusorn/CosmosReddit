package com.hamburghini.playerplus.player.models;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.Format;
import androidx.media3.common.util.UnstableApi;

public class AudioTrack {

    private final int bitrate;
    private final String codecs;
    private final String language;
    private final String label;
    private final String id;

    private AudioTrack(
            int bitrate,
            String codecs,
            String language,
            String label,
            String id
    ) {
        this.bitrate = bitrate;
        this.codecs = codecs;
        this.language = language;
        this.label = label;
        this.id = id;
    }

    @OptIn(markerClass = UnstableApi.class)
    public static AudioTrack init(Format format) {
        return new AudioTrack(
                format.bitrate,
                format.codecs,
                format.language,
                format.label,
                format.id
        );
    }

    public int getBitrate() {
        return bitrate;
    }

    public String getCodecs() {
        return codecs;
    }

    public String getLanguage() {
        return language;
    }

    public String getLabel() {
        return label;
    }

    public String getId() {
        return id;
    }

    @NonNull
    @Override
    public String toString() {
        return "AudioTrack(" +
                "bitrate=" + bitrate +
                ", codecs=" + codecs +
                ", language=" + language +
                ", label=" + label +
                ", id=" + id + ")";
    }

//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) return true;
//        if (obj == null || getClass() != obj.getClass()) return false;
//
//        AudioTrack other = (AudioTrack) obj;
//
//        if (bitrate != other.bitrate) return false;
//        if (codecs != null ? !codecs.equals(other.codecs) : other.codecs != null) return false;
//        if (language != null ? !language.equals(other.language) : other.language != null) return false;
//        if (label != null ? !label.equals(other.label) : other.label != null) return false;
//        return id != null ? id.equals(other.id) : other.id == null;
//    }
//
//    @Override
//    public int hashCode() {
//        int result = bitrate;
//        result = 31 * result + (codecs != null ? codecs.hashCode() : 0);
//        result = 31 * result + (language != null ? language.hashCode() : 0);
//        result = 31 * result + (label != null ? label.hashCode() : 0);
//        result = 31 * result + (id != null ? id.hashCode() : 0);
//        return result;
//    }
}