package com.hamburghini.playerplus.player.models;

import androidx.annotation.OptIn;
import androidx.media3.common.Format;
import androidx.media3.common.util.UnstableApi;

public class VideoTrack {

    private final int bitrate;
    private final int width;
    private final int height;
    private final float frameRate;
    private final String codecs;
    private final String mimeType;
    private final String id;

    private VideoTrack(
            int bitrate,
            int width,
            int height,
            float frameRate,
            String codecs,
            String mimeType,
            String id
    ) {
        this.bitrate = bitrate;
        this.width = width;
        this.height = height;
        this.frameRate = frameRate;
        this.codecs = codecs;
        this.mimeType = mimeType;
        this.id = id;
    }

    @OptIn(markerClass = UnstableApi.class)
    public static VideoTrack init(Format format) {
        return new VideoTrack(
                format.bitrate,
                format.width,
                format.height,
                format.frameRate,
                format.codecs != null ? format.codecs : "",
                format.sampleMimeType != null ? format.sampleMimeType : "",
                format.id
        );
    }

    public int getBitrate() {
        return bitrate;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public float getFrameRate() {
        return frameRate;
    }

    public String getCodecs() {
        return codecs;
    }

    public String getMimeType() {
        return mimeType;
    }

    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        return "VideoTrack(" +
                "bitrate=" + bitrate +
                ", width=" + width +
                ", height=" + height +
                ", frameRate=" + frameRate +
                ", codecs=" + codecs +
                ", mimeType=" + mimeType +
                ", id=" + id + ")";
    }

//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj) return true;
//        if (obj == null || getClass() != obj.getClass()) return false;
//
//        VideoTrack other = (VideoTrack) obj;
//
//        if (bitrate != other.bitrate) return false;
//        if (width != other.width) return false;
//        if (height != other.height) return false;
//        if (Float.compare(other.frameRate, frameRate) != 0) return false;
//        if (!codecs.equals(other.codecs)) return false;
//        if (!mimeType.equals(other.mimeType)) return false;
//        return id != null ? id.equals(other.id) : other.id == null;
//    }
//
//    @Override
//    public int hashCode() {
//        int result = bitrate;
//        result = 31 * result + width;
//        result = 31 * result + height;
//        result = 31 * result + Float.hashCode(frameRate);
//        result = 31 * result + codecs.hashCode();
//        result = 31 * result + mimeType.hashCode();
//        result = 31 * result + (id != null ? id.hashCode() : 0);
//        return result;
//    }
}