package com.hamburghini.playerplus.plugin;

import android.content.Context;

import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.download.DownloadTracker;
import com.hamburghini.playerplus.download.Downloader;
import com.hamburghini.playerplus.download.PlayerDownloadService;

public class DownloadPlugin implements Plugin {
    private final Class<? extends PlayerDownloadService> downloadServiceClass;

    /**
     * Create a download plugin with a custom download service
     *
     * @param downloadServiceClass Custom download service class (must extend PlayerDownloadService)
     */
    public DownloadPlugin(Class<? extends PlayerDownloadService> downloadServiceClass) {
        if (downloadServiceClass == null) {
            throw new IllegalArgumentException("downloadServiceClass cannot be null");
        }
        this.downloadServiceClass = downloadServiceClass;
    }

    @Override
    public void onRegister(Context context) {
        DownloadTracker.setDownloadServiceClass(downloadServiceClass);
        Downloader.initialize(context);
        SDKLogger.i("Download service registered: " + downloadServiceClass.getSimpleName());
    }

    @Override
    public void onUnregister() {
        // Reset to default service if needed
        DownloadTracker.setDownloadServiceClass(PlayerDownloadService.class);
        SDKLogger.i("Download service unregistered");
    }

    @Override
    public String getName() {
        return "DownloadPlugin";
    }

    public Class<? extends PlayerDownloadService> getDownloadServiceClass() {
        return downloadServiceClass;
    }
}