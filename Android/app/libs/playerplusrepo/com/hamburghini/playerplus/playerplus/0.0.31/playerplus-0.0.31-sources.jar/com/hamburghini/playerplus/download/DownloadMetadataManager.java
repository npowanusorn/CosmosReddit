package com.hamburghini.playerplus.download;

import android.content.Context;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hamburghini.playerplus.exceptions.PlayerPlusException;
import com.hamburghini.playerplus.SDKLogger;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class DownloadMetadataManager {

    private static volatile DownloadMetadataManager instance;

    private Set<DownloadMetadata> metadataSet = new HashSet<>();
    private final Context context;
    private final Gson gson;

    private DownloadMetadataManager(Context context) {
        this.context = context;
        this.gson = new Gson();
        load();
    }

    public static void initialize(Context context) {
        if (instance == null) {
            synchronized (DownloadMetadataManager.class) {
                if (instance == null) {
                    instance = new DownloadMetadataManager(context.getApplicationContext());
                }
            }
        }
    }

    public static DownloadMetadataManager getInstance() {
        if (instance == null) {
            throw new PlayerPlusException("MediaMetadataManager not initialized");
        }
        return instance;
    }

    public void load() {
        try (FileInputStream fileInputStream = context.openFileInput("METADATA");
             InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
             BufferedReader reader = new BufferedReader(inputStreamReader)
        ) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            SDKLogger.d("load: " + sb);
            Type listType = TypeToken.getParameterized(Set.class, DownloadMetadata.class).getType();
            metadataSet = gson.fromJson(sb.toString(), listType);

            SDKLogger.d("metadata set: " + metadataSet);
        } catch (FileNotFoundException e) {
            store();
        } catch (Exception e) {
            SDKLogger.e("mediametadatamanager load exception", e);
        }
    }

    public void store() {
        String json = gson.toJson(metadataSet);
        SDKLogger.d("store: " + json);
        try (FileOutputStream fos = context.openFileOutput("METADATA", Context.MODE_PRIVATE)) {
            fos.write(json.getBytes());
        } catch (Exception e) {
            SDKLogger.e("mediametadatamanager store exception", e);
        }
    }

    public void add(@NonNull DownloadMetadata downloadMetadata) {
        metadataSet.add(downloadMetadata);
        store();
    }

    public void remove(@NonNull DownloadMetadata downloadMetadata) {
        metadataSet.remove(downloadMetadata);
        store();
    }

    public void remove(@NonNull String id) {
        metadataSet.removeIf(item -> item.getId().equals(id));
        store();
    }

    public Set<DownloadMetadata> getMetadataList() {
        return Collections.unmodifiableSet(metadataSet);
    }

    public DownloadMetadata get(@NonNull String id) {
        return metadataSet.stream()
                .filter(downloadMetadata -> downloadMetadata.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

}
