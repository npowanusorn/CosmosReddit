package com.hamburghini.playerplus;

import android.util.Log;

public class SDKLogger {

    private static final String TAG = "Player+";

    private static boolean isEnabled = true;

    public static boolean isEnabled() {
        return isEnabled;
    }

    public static void setEnabled(boolean enabled) {
        isEnabled = enabled;
    }

    public static void v(String message, Throwable throwable) {
        if (isEnabled) {
            Log.v(TAG, message, throwable);
        }
    }

    public static void v(String message) {
        v(message, null);
    }

    public static void d(String message, Throwable throwable) {
        if (isEnabled) {
            Log.d(TAG, message, throwable);
        }
    }

    public static void d(String message) {
        d(message, null);
    }

    public static void i(String message, Throwable throwable) {
        if (isEnabled) {
            Log.i(TAG, message, throwable);
        }
    }

    public static void i(String message) {
        i(message, null);
    }

    public static void w(String message, Throwable throwable) {
        if (isEnabled) {
            Log.w(TAG, message, throwable);
        }
    }

    public static void w(String message) {
        w(message, null);
    }

    public static void e(String message, Throwable throwable) {
        if (isEnabled) {
            Log.e(TAG, message, throwable);
        }
    }

    public static void e(String message) {
        e(message, null);
    }

    public static void wtf(String message, Throwable throwable) {
        if (isEnabled) {
            Log.wtf(TAG, message, throwable);
        }
    }

    public static void wtf(String message) {
        wtf(message, null);
    }
}