package com.hamburghini.playerplus.plugin;

import android.content.Context;

public interface Plugin {
    /**
     * Called when the plugin is registered
     */
    void onRegister(Context context);

    /**
     * Called when the plugin is unregistered
     */
    void onUnregister();

    /**
     * Get the plugin name
     */
    String getName();
}