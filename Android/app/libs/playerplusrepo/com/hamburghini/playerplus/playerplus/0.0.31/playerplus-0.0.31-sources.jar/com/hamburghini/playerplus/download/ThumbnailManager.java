package com.hamburghini.playerplus.download;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;

import com.hamburghini.playerplus.SDKLogger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Manages thumbnail downloads and storage
 */
class ThumbnailManager {

    private static final String THUMBNAIL_DIRECTORY = "player_plus_thumbnails";
    private static final String THUMBNAIL_EXTENSION = ".jpg";
    private static final int THUMBNAIL_QUALITY = 85;
    private static final int CONNECTION_TIMEOUT = 10000;
    private static final int READ_TIMEOUT = 15000;

    private static volatile ThumbnailManager instance;

    private final Context context;
    private final File thumbnailDirectory;
    private final ExecutorService executorService;
    private final Handler mainHandler;

    /**
     * Callback interface for thumbnail operations
     */
    public interface ThumbnailCallback {
        void onResult(boolean success, String path);
    }

    private ThumbnailManager(Context context) {
        this.context = context.getApplicationContext();
        File externalFilesDir = context.getExternalFilesDir(null);
        this.thumbnailDirectory = new File(
                externalFilesDir != null ? externalFilesDir : context.getFilesDir(),
                THUMBNAIL_DIRECTORY
        );
        this.executorService = Executors.newFixedThreadPool(3);
        this.mainHandler = new Handler(Looper.getMainLooper());

        if (!thumbnailDirectory.exists()) {
            thumbnailDirectory.mkdirs();
            SDKLogger.d("Created thumbnail directory: " + thumbnailDirectory.getAbsolutePath());
        }
    }

    static ThumbnailManager getInstance(Context context) {
        if (instance == null) {
            synchronized (ThumbnailManager.class) {
                if (instance == null) {
                    instance = new ThumbnailManager(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    /**
     * Download and save a thumbnail for a content ID
     * @param id Content ID
     * @param thumbnailUrl URL of the thumbnail image
     * @param callback Callback for success/failure
     */
    void downloadThumbnail(String id, String thumbnailUrl, ThumbnailCallback callback) {
        executorService.submit(() -> {
            try {
                SDKLogger.d("Downloading thumbnail for id: " + id + " from " + thumbnailUrl);

                Bitmap bitmap = downloadBitmap(thumbnailUrl);
                if (bitmap != null) {
                    boolean saved = saveThumbnail(id, bitmap);
                    String thumbnailPath = getThumbnailPath(id);

                    mainHandler.post(() -> {
                        if (saved) {
                            SDKLogger.i("Thumbnail saved successfully for id: " + id);
                            if (callback != null) {
                                callback.onResult(true, thumbnailPath);
                            }
                        } else {
                            SDKLogger.e("Failed to save thumbnail for id: " + id);
                            if (callback != null) {
                                callback.onResult(false, null);
                            }
                        }
                    });
                    bitmap.recycle();
                } else {
                    mainHandler.post(() -> {
                        SDKLogger.e("Failed to download thumbnail for id: " + id);
                        if (callback != null) {
                            callback.onResult(false, null);
                        }
                    });
                }
            } catch (Exception e) {
                mainHandler.post(() -> {
                    SDKLogger.e("Error downloading thumbnail for id: " + id, e);
                    if (callback != null) {
                        callback.onResult(false, null);
                    }
                });
            }
        });
    }

    /**
     * Download and save a thumbnail for a content ID (wrapper for Downloader usage)
     * @param id Content ID
     * @param thumbnailUrl URL of the thumbnail image
     * @param callback Callback for success/failure (functional interface style)
     */
    void downloadAndSaveThumbnail(String id, String thumbnailUrl, ThumbnailCallback callback) {
        downloadThumbnail(id, thumbnailUrl, callback);
    }

    /**
     * Download bitmap from URL
     */
    private Bitmap downloadBitmap(String urlString) {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(CONNECTION_TIMEOUT);
            connection.setReadTimeout(READ_TIMEOUT);
            connection.setDoInput(true);
            connection.connect();

            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = connection.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
                return bitmap;
            } else {
                SDKLogger.e("HTTP error downloading thumbnail: " + connection.getResponseCode());
                return null;
            }
        } catch (IOException e) {
            SDKLogger.e("IOException downloading thumbnail", e);
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /**
     * Save bitmap to local storage
     */
    private boolean saveThumbnail(String id, Bitmap bitmap) {
        File file = getThumbnailFile(id);
        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, THUMBNAIL_QUALITY, out);
            out.flush();
            out.close();
            SDKLogger.d("Thumbnail saved to: " + file.getAbsolutePath());
            return true;
        } catch (IOException e) {
            SDKLogger.e("Failed to save thumbnail", e);
            return false;
        }
    }

    /**
     * Delete thumbnail for a content ID
     */
    boolean deleteThumbnail(String id) {
        File file = getThumbnailFile(id);
        if (file.exists()) {
            boolean deleted = file.delete();
            if (deleted) {
                SDKLogger.d("Thumbnail deleted for id: " + id);
            } else {
                SDKLogger.e("Failed to delete thumbnail for id: " + id);
            }
            return deleted;
        } else {
            SDKLogger.d("No thumbnail file to delete for id: " + id);
            return true;
        }
    }

    /**
     * Check if thumbnail exists for a content ID
     */
    boolean hasThumbnail(String id) {
        return getThumbnailFile(id).exists();
    }

    /**
     * Get the file path for a thumbnail
     */
    String getThumbnailPath(String id) {
        File file = getThumbnailFile(id);
        return file.exists() ? file.getAbsolutePath() : null;
    }

    /**
     * Get thumbnail file for a content ID
     */
    private File getThumbnailFile(String id) {
        String sanitizedId = id.replaceAll("[^a-zA-Z0-9._-]", "_");
        return new File(thumbnailDirectory, sanitizedId + THUMBNAIL_EXTENSION);
    }

    /**
     * Get all thumbnail files
     */
    List<File> getAllThumbnails() {
        File[] files = thumbnailDirectory.listFiles();
        if (files != null) {
            List<File> result = new ArrayList<>();
            for (File file : files) {
                result.add(file);
            }
            return result;
        }
        return new ArrayList<>();
    }

    /**
     * Delete all thumbnails
     */
    boolean deleteAllThumbnails() {
        List<File> files = getAllThumbnails();
        boolean allDeleted = true;
        for (File file : files) {
            if (!file.delete()) {
                allDeleted = false;
                SDKLogger.e("Failed to delete thumbnail: " + file.getName());
            }
        }
        if (allDeleted) {
            SDKLogger.i("All thumbnails deleted");
        }
        return allDeleted;
    }

    /**
     * Get total size of all thumbnails in bytes
     */
    long getTotalThumbnailSize() {
        long totalSize = 0;
        for (File file : getAllThumbnails()) {
            totalSize += file.length();
        }
        return totalSize;
    }

    /**
     * Release resources
     */
    void release() {
        executorService.shutdown();
        SDKLogger.d("ThumbnailManager released");
    }
}