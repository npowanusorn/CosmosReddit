package com.hamburghini.playerplus.player;

import androidx.media3.common.PlaybackException;
import androidx.media3.common.VideoSize;

public interface PlayerEventListener {
    void onStateChanged(PlayerController.State state);
    void onIsPlayingChanged(boolean isPlaying);
    void onVideoSizeChanged(VideoSize videoSize);
    void onPlayerError(PlaybackException e);
    void onPositionChanged(long oldPositionMs, long newPositionMs);
}