package com.hamburghini.playerplus.player;

public enum RepeatMode {
    OFF, ONE, ALL
}