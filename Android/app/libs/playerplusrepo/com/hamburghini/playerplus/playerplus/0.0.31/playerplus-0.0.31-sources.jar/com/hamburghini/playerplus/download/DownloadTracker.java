package com.hamburghini.playerplus.download;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.annotation.RestrictTo;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.dash.DashUtil;
import androidx.media3.exoplayer.dash.manifest.AdaptationSet;
import androidx.media3.exoplayer.dash.manifest.DashManifest;
import androidx.media3.exoplayer.dash.manifest.Period;
import androidx.media3.exoplayer.dash.manifest.Representation;
import androidx.media3.exoplayer.offline.DownloadCursor;
import androidx.media3.exoplayer.offline.DownloadHelper;
import androidx.media3.exoplayer.offline.DownloadRequest;
import androidx.media3.exoplayer.offline.DownloadService;
import androidx.media3.exoplayer.source.TrackGroupArray;
import androidx.media3.exoplayer.trackselection.MappingTrackSelector.MappedTrackInfo;

import com.google.gson.Gson;
import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.player.DrmScheme;
import com.hamburghini.playerplus.player.configs.DownloadConfig;
import com.hamburghini.playerplus.player.configs.DrmConfig;
import com.hamburghini.playerplus.player.models.AudioTrack;
import com.hamburghini.playerplus.player.models.VideoTrack;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Internal download tracker - monitors download state
 * Users should interact with Downloader instead
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@OptIn(markerClass = UnstableApi.class)
public class DownloadTracker {

    interface Listener {
        void onDownloadsChanged();
        default void onDownloadChanged(Download download) {}
        default void onDownloadRemoved(Download download) {}
    }

    @SuppressLint("StaticFieldLeak")
    private static volatile DownloadTracker instance;

    static volatile Class<? extends PlayerDownloadService> downloadServiceClass;

    private final Context appContext;
    private final CopyOnWriteArraySet<Listener> listeners = new CopyOnWriteArraySet<>();
    private final Map<String, androidx.media3.exoplayer.offline.Download> downloads = new HashMap<>(); // id -> Download
    private final androidx.media3.exoplayer.offline.DownloadManager media3DownloadManager;
    private final DefaultHttpDataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory();
    private final ThumbnailManager thumbnailManager;

    // Track active license fetchers by id
    private final Map<String, OfflineLicenseFetcher> activeLicenseFetchers = new HashMap<>();

    // Track pending thumbnail downloads
    private final Map<String, String> pendingThumbnails = new HashMap<>();

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final DownloadMetadataManager downloadMetadataManager = DownloadMetadataManager.getInstance();

    private DownloadTracker(Context context) {
        this.appContext = context.getApplicationContext();
        this.thumbnailManager = ThumbnailManager.getInstance(context);
        this.media3DownloadManager = DownloadManager.getInstance(appContext).media3DownloadManager;
        this.media3DownloadManager.addListener(new DownloadManagerListener());
        loadDownloads();
        SDKLogger.i("DownloadTracker initialized with " + downloads.size() + " downloads");
    }

    static DownloadTracker getInstance(Context context) {
        if (instance == null) {
            synchronized (DownloadTracker.class) {
                if (instance == null) {
                    instance = new DownloadTracker(context);
                }
            }
        }
        return instance;
    }

    public static void setDownloadServiceClass(Class<? extends PlayerDownloadService> serviceClass) {
        downloadServiceClass = serviceClass;
    }

    void addListener(Listener listener) {
        listeners.add(listener);
    }

    void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    boolean isDownloadedById(String id) {
        androidx.media3.exoplayer.offline.Download download = downloads.get(id);
        return download != null && download.state == androidx.media3.exoplayer.offline.Download.STATE_COMPLETED;
    }

    Download getDownloadById(String id) {
        androidx.media3.exoplayer.offline.Download download = downloads.get(id);
        if (download == null) {
            return null;
        }
        String thumbnailPath = thumbnailManager.getThumbnailPath(id);
        long estimatedSize = 0;
        for (DownloadMetadata metadata: downloadMetadataManager.getMetadataList()) {
            if (metadata.getId().equals(id)) {
                estimatedSize = metadata.getEstimatedSize();
            }
        }
        return Download.fromDownload(download, thumbnailPath, estimatedSize);
    }

    List<Download> getAllDownloads() {
        List<Download> result = new ArrayList<>();
        for (androidx.media3.exoplayer.offline.Download download : downloads.values()) {
            String id = download.request.id;
            String thumbnailPath = thumbnailManager.getThumbnailPath(id);
            long estimatedSize = 0;
            for (DownloadMetadata metadata: downloadMetadataManager.getMetadataList()) {
                if (metadata.getId().equals(id)) {
                    estimatedSize = metadata.getEstimatedSize();
                }
            }
            result.add(Download.fromDownload(download, thumbnailPath, estimatedSize));
        }
        return result;
    }

    List<Download> getDownloadsByState(int state) {
        List<Download> result = new ArrayList<>();
        for (androidx.media3.exoplayer.offline.Download download : downloads.values()) {
            if (download.state == state) {
                String id = download.request.id;
                String thumbnailPath = thumbnailManager.getThumbnailPath(id);
                long estimatedSize = 0;
                for (DownloadMetadata metadata: downloadMetadataManager.getMetadataList()) {
                    if (metadata.getId().equals(id)) {
                        estimatedSize = metadata.getEstimatedSize();
                    }
                }
                result.add(Download.fromDownload(download, thumbnailPath, estimatedSize));
            }
        }
        return result;
    }


    void prepareDownload(DownloadConfig config, Downloader.OnModelReadyCallback callback) {
        try {
            androidx.media3.exoplayer.offline.Download existingDownload = downloads.get(config.getId());
            if (existingDownload != null && existingDownload.state != androidx.media3.exoplayer.offline.Download.STATE_FAILED) {
                SDKLogger.d("Download already exists for id: " + config.getId());
                return;
            }

            // Store thumbnail URL for later download
            if (config.getThumbnailUrl() != null) {
                pendingThumbnails.put(config.getId(), config.getThumbnailUrl());
            }

            MediaItem mediaItem = buildMediaItemForDownload(config);

            // Check if content type is manually specified
            if (config.getContentType() == DownloadConfig.ContentType.PROGRESSIVE) {
                SDKLogger.i("Content type manually set to PROGRESSIVE");
                handlePrepareWithContentType(config, mediaItem, true, callback);
                return;
            } else if (config.getContentType() == DownloadConfig.ContentType.ADAPTIVE) {
                SDKLogger.i("Content type manually set to ADAPTIVE");
                handlePrepareWithContentType(config, mediaItem, false, callback);
                return;
            }

            // AUTO detection mode
            SDKLogger.d("Auto-detecting content type for: " + config.getContentUrl());

            // Detect content type from URL
            boolean urlHasExtension = hasProgressiveFileExtension(config.getContentUrl()) ||
                    hasManifestIndicators(config.getContentUrl());

            if (urlHasExtension) {
                // URL has clear extension, proceed with synchronous detection
                boolean isProgressiveContent = isProgressiveDownload(config.getContentUrl());
                handlePrepareWithContentType(config, mediaItem, isProgressiveContent, callback);
            } else {
                // Ambiguous URL (e.g., API endpoint), try HTTP HEAD request
                SDKLogger.d("Ambiguous URL detected, checking Content-Type header: " + config.getContentUrl());

                detectContentTypeFromHeaders(config.getContentUrl(), (isProgressive, contentType) -> {
                    SDKLogger.i("Content-Type detection result: " + (isProgressive ? "progressive" : "adaptive") +
                            " (Content-Type: " + contentType + ")");
                    handlePrepareWithContentType(config, mediaItem, isProgressive, callback);
                });
            }
        } catch (Exception e) {
            SDKLogger.e("Failed to start download: " + config.getContentUrl(), e);
            pendingThumbnails.remove(config.getId());
            callback.onException(e);
        }
    }

    /**
     * Handle download preparation after content type is determined
     */
    private void handlePrepareWithContentType(
            DownloadConfig config,
            MediaItem mediaItem,
            boolean isProgressiveContent,
            Downloader.OnModelReadyCallback callback
    ) {
        try {
            if (isProgressiveContent) {
                SDKLogger.i("Detected progressive download");
                // For progressive downloads, create a simple model without track selection
                String thumbnailPath = thumbnailManager.hasThumbnail(config.getId())
                        ? thumbnailManager.getThumbnailPath(config.getId())
                        : null;

                DownloadModel downloadModel = new DownloadModel(
                        config.getId(),
                        config.getContentUrl(),
                        new VideoTrack[0],
                        new AudioTrack[0],
                        thumbnailPath,
                        null,
                        config.getDrmConfig(),
                        config.getData()
                );

                callback.onModelAvailable(downloadModel);
            } else {
                SDKLogger.i("Detected adaptive streaming content");
                // Use DownloadHelper for adaptive content
                DownloadHelper downloadHelper = new DownloadHelper.Factory()
                        .setRenderersFactory(new DefaultRenderersFactory(appContext))
                        .setDataSourceFactory(dataSourceFactory)
                        .create(mediaItem);

                downloadHelper.prepare(new DownloadHelper.Callback() {
                    @Override
                    public void onPrepared(@NonNull DownloadHelper helper, boolean tracksInfoAvailable) {
                        SDKLogger.d("tracksInfoAvailable: " + tracksInfoAvailable);

                        List<VideoTrack> videoTracks = new ArrayList<>();
                        List<AudioTrack> audioTracks = new ArrayList<>();

                        if (tracksInfoAvailable) {
                            extractTracksInfo(helper, videoTracks, audioTracks);
                        }

                        SDKLogger.i("videoTracks: " + videoTracks);
                        SDKLogger.i("audioTracks: " + audioTracks);

                        String thumbnailPath = thumbnailManager.hasThumbnail(config.getId())
                                ? thumbnailManager.getThumbnailPath(config.getId())
                                : null;

                        DownloadModel downloadModel = new DownloadModel(
                                config.getId(),
                                config.getContentUrl(),
                                videoTracks.toArray(new VideoTrack[0]),
                                audioTracks.toArray(new AudioTrack[0]),
                                thumbnailPath,
                                helper,
                                config.getDrmConfig(),
                                config.getData()
                        );

                        callback.onModelAvailable(downloadModel);
                    }

                    @Override
                    public void onPrepareError(@NonNull DownloadHelper helper, @NonNull IOException e) {
                        SDKLogger.e("Failed to prepare download", e);
                        helper.release();
                        pendingThumbnails.remove(config.getId());
                        callback.onException(e);
                    }
                });
            }
        } catch (Exception e) {
            SDKLogger.e("Failed to handle prepare with content type", e);
            pendingThumbnails.remove(config.getId());
            callback.onException(e);
        }
    }

    /**
     * Detect if the URL points to progressive download content (MP4, MKV, WebM)
     * Uses multiple detection strategies:
     * 1. URL extension check (fastest)
     * 2. Manifest format exclusion (DASH/HLS indicators)
     * 3. HTTP HEAD request for Content-Type (most reliable but slower)
     */
    private boolean isProgressiveDownload(String url) {
        // Strategy 1: Check URL extension (fast path)
        if (hasProgressiveFileExtension(url)) {
            SDKLogger.d("Detected progressive download from file extension: " + url);
            return true;
        }

        // Strategy 2: Check for manifest format indicators (exclusion)
        if (hasManifestIndicators(url)) {
            SDKLogger.d("Detected adaptive streaming from manifest indicators: " + url);
            return false;
        }

        // Strategy 3: If ambiguous, default to adaptive streaming (safer)
        // DownloadHelper can handle both, but progressive path is optimized
        SDKLogger.d("Ambiguous URL format, defaulting to adaptive streaming: " + url);
        return false;
    }

    /**
     * Check if URL has progressive download file extension
     */
    private boolean hasProgressiveFileExtension(String url) {
        String lowerUrl = url.toLowerCase();

        // Direct file extensions
        if (lowerUrl.endsWith(".mp4") ||
                lowerUrl.endsWith(".mkv") ||
                lowerUrl.endsWith(".webm") ||
                lowerUrl.endsWith(".avi") ||
                lowerUrl.endsWith(".mov") ||
                lowerUrl.endsWith(".m4v") ||
                lowerUrl.endsWith(".3gp") ||
                lowerUrl.endsWith(".flv")) {
            return true;
        }

        // Extensions with query parameters
        return lowerUrl.contains(".mp4?") ||
                lowerUrl.contains(".mkv?") ||
                lowerUrl.contains(".webm?") ||
                lowerUrl.contains(".avi?") ||
                lowerUrl.contains(".mov?") ||
                lowerUrl.contains(".m4v?");
    }

    /**
     * Check if URL has manifest format indicators (DASH, HLS, SmoothStreaming)
     */
    private boolean hasManifestIndicators(String url) {
        String lowerUrl = url.toLowerCase();

        // DASH manifest
        if (lowerUrl.endsWith(".mpd") || lowerUrl.contains(".mpd?")) {
            return true;
        }

        // HLS manifest
        if (lowerUrl.endsWith(".m3u8") || lowerUrl.contains(".m3u8?")) {
            return true;
        }

        // SmoothStreaming manifest
        if (lowerUrl.endsWith("/manifest") ||
                lowerUrl.contains("/manifest?") ||
                lowerUrl.contains(".ism") ||
                lowerUrl.contains(".isml")) {
            return true;
        }

        // Common CDN/API patterns that indicate DASH
        return lowerUrl.contains("/dash/") ||
                lowerUrl.contains("/hls/") ||
                lowerUrl.contains("manifest") ||
                lowerUrl.contains("playlist");
    }

    /**
     * Perform HTTP HEAD request to check Content-Type header
     * This is the most reliable method but requires network call
     * Only call this for ambiguous URLs
     */
    private void detectContentTypeFromHeaders(String url, ContentTypeCallback callback) {
        executorService.submit(() -> {
            HttpURLConnection connection = null;
            try {
                URL urlObj = new URL(url);
                connection = (HttpURLConnection) urlObj.openConnection();
                connection.setRequestMethod("HEAD");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.connect();

                String contentType = connection.getContentType();
                SDKLogger.d("Content-Type from HEAD request: " + contentType);

                boolean isProgressive = isProgressiveContentType(contentType);

                mainHandler.post(() -> callback.onDetected(isProgressive, contentType));

            } catch (Exception e) {
                SDKLogger.e("Failed to detect content type from headers", e);
                // On error, default to adaptive streaming (safer)
                mainHandler.post(() -> callback.onDetected(false, null));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        });
    }

    /**
     * Check if Content-Type indicates progressive download
     */
    private boolean isProgressiveContentType(String contentType) {
        if (contentType == null) {
            return false;
        }

        String lowerType = contentType.toLowerCase();

        // Video container formats (progressive)
        return lowerType.contains("video/mp4") ||
                lowerType.contains("video/x-matroska") ||
                lowerType.contains("video/webm") ||
                lowerType.contains("video/quicktime") ||
                lowerType.contains("video/x-msvideo") ||
                lowerType.contains("video/3gpp") ||
                lowerType.contains("video/x-flv") ||
                lowerType.contains("application/mp4") ||
                lowerType.contains("application/octet-stream");
    }

    /**
     * Callback interface for content type detection
     */
    private interface ContentTypeCallback {
        void onDetected(boolean isProgressive, String contentType);
    }

    void startDownload(DownloadModel downloadModel, Downloader.OnDownloadErrorCallback callback) {
        DownloadHelper helper = downloadModel.getDownloadHelper();

        // Handle progressive downloads (MP4, etc.) - no DownloadHelper
        if (helper == null) {
            SDKLogger.i("Starting progressive download for: " + downloadModel.getId());
            startProgressiveDownload(downloadModel, callback);
            return;
        }

        // Handle adaptive streaming downloads (DASH, HLS) - with DownloadHelper
        SDKLogger.i("Starting adaptive streaming download for: " + downloadModel.getId());

        // Load manifest for size estimation (only for DASH)
        if (downloadModel.getContentUrl().contains(".mpd")) {
            new Thread(() -> {
                try {
                    DashManifest manifest = DashUtil.loadManifest(
                            dataSourceFactory.createDataSource(),
                            Uri.parse(downloadModel.getContentUrl())
                    );

                    SDKLogger.i("Manifest loaded successfully");
                    SDKLogger.d("Manifest has " + manifest.getPeriodCount() + " periods");

                    DownloadMetadata downloadMetadata = new DownloadMetadata(
                            downloadModel.getId(),
                            downloadModel.getDrmConfig(),
                            estimateManifestSizeForModel(manifest, downloadModel),
                            downloadModel.getData()
                    );
                    downloadMetadataManager.add(downloadMetadata);
                    downloadMetadataManager.store();
                } catch (IOException e) {
                    SDKLogger.e("load manifest error", e);
                }
            }).start();
        }

        String thumbnailUrl = pendingThumbnails.get(downloadModel.getId());
        if (thumbnailUrl != null) {
            thumbnailManager.downloadThumbnail(downloadModel.getId(), thumbnailUrl, (success, path) -> {
                if (success) {
                    SDKLogger.i("Thumbnail downloaded for " + downloadModel.getId() + ": " + path);
                } else {
                    SDKLogger.w("Failed to download thumbnail for " + downloadModel.getId());
                }
            });
            pendingThumbnails.remove(downloadModel.getId());
        }

        for (int periodIndex = 0; periodIndex < helper.getPeriodCount(); periodIndex++) {
            helper.clearTrackSelections(periodIndex);
        }

        applyTrackSelections(helper, downloadModel);

        DrmConfig drmConfig = downloadModel.getDrmConfig();

        if (drmConfig != null) {
            SDKLogger.d("DRM content detected, fetching offline license first");

            // Build MediaItem with DRM configuration
            UUID drmUuid = getDrmUuid(drmConfig.getDrmScheme());

            if (drmUuid.equals(C.WIDEVINE_UUID)) {
                fetchOfflineLicenseThenDownload(helper, downloadModel.getDrmConfig(), downloadModel.getId(), callback);
            } else {
                // Non-Widevine DRM doesn't support offline licenses
                startDownloadWithHelper(helper, null, downloadModel.getId(), null);
            }
        } else {
            startDownloadWithHelper(helper, null, downloadModel.getId(), null);
        }
    }

    /**
     * Start a progressive download (MP4, MKV, WebM) without DownloadHelper
     */
    private void startProgressiveDownload(DownloadModel downloadModel, Downloader.OnDownloadErrorCallback callback) {
        try {
            DownloadMetadata downloadMetadata = new DownloadMetadata(
                    downloadModel.getId(),
                    downloadModel.getDrmConfig(),
                    0,
                    downloadModel.getData()
            );
            downloadMetadataManager.add(downloadMetadata);
            downloadMetadataManager.store();

            // Handle thumbnail download
            String thumbnailUrl = pendingThumbnails.get(downloadModel.getId());
            if (thumbnailUrl != null) {
                thumbnailManager.downloadThumbnail(downloadModel.getId(), thumbnailUrl, (success, path) -> {
                    if (success) {
                        SDKLogger.i("Thumbnail downloaded for " + downloadModel.getId() + ": " + path);
                    } else {
                        SDKLogger.w("Failed to download thumbnail for " + downloadModel.getId());
                    }
                });
                pendingThumbnails.remove(downloadModel.getId());
            }

            // Build MediaItem for progressive download
            MediaItem.Builder mediaItemBuilder = new MediaItem.Builder()
                    .setUri(downloadModel.getContentUrl());

            // Add DRM configuration if present
            DrmConfig drmConfig = downloadModel.getDrmConfig();
            if (drmConfig != null) {
                UUID drmUuid = getDrmUuid(drmConfig.getDrmScheme());
                mediaItemBuilder.setDrmConfiguration(
                        new MediaItem.DrmConfiguration.Builder(drmUuid)
                                .setLicenseUri(drmConfig.getLicenseUrl())
                                .build()
                );

                // For Widevine DRM on progressive content, we still need offline license
                if (drmUuid.equals(C.WIDEVINE_UUID)) {
                    SDKLogger.d("Fetching offline license for progressive DRM content");
                    fetchOfflineLicenseForProgressive(downloadModel, callback);
                    return;
                }
            }

            // Create download request for progressive content
            Gson gson = new Gson();
            byte[] data = gson.toJson(drmConfig).getBytes(StandardCharsets.UTF_8);

            DownloadRequest downloadRequest = new DownloadRequest.Builder(
                    downloadModel.getId(),
                    Uri.parse(downloadModel.getContentUrl())
            )
                    .setData(data)
                    .build();

            // Send download request to service
            DownloadService.sendAddDownload(
                    appContext,
                    downloadServiceClass,
                    downloadRequest,
                    false
            );

            SDKLogger.i("Progressive download started for: " + downloadModel.getId());

        } catch (Exception e) {
            SDKLogger.e("Failed to start progressive download", e);
            if (callback != null) {
                callback.onError(e);
            }
        }
    }

    /**
     * Fetch offline license for progressive DRM content
     */
    private void fetchOfflineLicenseForProgressive(DownloadModel downloadModel, Downloader.OnDownloadErrorCallback callback) {
        DrmConfig drmConfig = downloadModel.getDrmConfig();
        assert drmConfig != null;
        MediaItem.DrmConfiguration mediaItemDrmConfig = new MediaItem.DrmConfiguration.Builder(getDrmUuid(drmConfig.getDrmScheme()))
                .setLicenseUri(drmConfig.getLicenseUrl())
                .build();

        // Create a simple format for license fetch
        Format format = new Format.Builder()
                .setContainerMimeType("video/mp4")
                .build();

        OfflineLicenseFetcher licenseFetcher = new OfflineLicenseFetcher(
                format,
                mediaItemDrmConfig,
                dataSourceFactory,
                new OfflineLicenseFetcher.Callback() {
                    @Override
                    public void onLicenseFetched(byte[] keySetId) {
                        SDKLogger.i("License fetched successfully for progressive content: " + downloadModel.getId());
                        activeLicenseFetchers.remove(downloadModel.getId());

                        // Create download request with keySetId
                        Gson gson = new Gson();
                        byte[] data = gson.toJson(drmConfig).getBytes(StandardCharsets.UTF_8);

                        DownloadRequest downloadRequest = new DownloadRequest.Builder(
                                downloadModel.getId(),
                                Uri.parse(downloadModel.getContentUrl())
                        )
                                .setData(data)
                                .setKeySetId(keySetId)
                                .build();

                        DownloadService.sendAddDownload(
                                appContext,
                                downloadServiceClass,
                                downloadRequest,
                                false
                        );

                        SDKLogger.i("Progressive DRM download started for: " + downloadModel.getId());
                    }

                    @Override
                    public void onLicenseFetchError(Exception error) {
                        SDKLogger.e("Failed to fetch license for progressive content: " + downloadModel.getId(), error);
                        activeLicenseFetchers.remove(downloadModel.getId());
                        if (callback != null) {
                            callback.onError(error);
                        }
                    }
                }
        );

        activeLicenseFetchers.put(downloadModel.getId(), licenseFetcher);
        licenseFetcher.execute();
    }

    private UUID getDrmUuid(DrmScheme drmScheme) {
        switch (drmScheme) {
            case WIDEVINE:
                return C.WIDEVINE_UUID;
            case PLAYREADY:
                return C.PLAYREADY_UUID;
            case CLEARKEY:
                return C.CLEARKEY_UUID;
            default:
                return C.UUID_NIL;
        }
    }

    private void applyTrackSelections(DownloadHelper helper, DownloadModel downloadModel) {
        int selectedVideoIndex = downloadModel.getSelectedVideoTrack();
        int[] selectedAudioIndices = downloadModel.getSelectedAudioTracks();
        Format selectedVideoFormat = findVideoFormatAtIndex(helper.getMappedTrackInfo(0), selectedVideoIndex);
        List<Format> selectedAudioFormats = findAudioFormatsAtIndices(helper.getMappedTrackInfo(0), selectedAudioIndices);

        TrackSelectionParameters.Builder parametersBuilder = new TrackSelectionParameters.Builder();

        // Apply video constraints
        if (selectedVideoFormat != null) {
            parametersBuilder
                    .setMaxVideoSize(selectedVideoFormat.width, selectedVideoFormat.height)
                    .setMaxVideoBitrate(selectedVideoFormat.bitrate)
                    .setMinVideoSize(selectedVideoFormat.width, selectedVideoFormat.height)
                    .setMinVideoBitrate(selectedVideoFormat.bitrate);
            SDKLogger.i("Video constraints: " + selectedVideoFormat.width + "x" +
                    selectedVideoFormat.height + " @ " + selectedVideoFormat.bitrate + " bps");
        }

        TrackSelectionParameters parameters = parametersBuilder.build();

        // Apply audio constraints
        String[] audioLanguages = new String[selectedAudioFormats.size()];
        if (!selectedAudioFormats.isEmpty()) {
            for (int i = 0; i < selectedAudioFormats.size(); i++) {
                Format audioFormat = selectedAudioFormats.get(i);
                if (audioFormat.language != null) {
                    audioLanguages[i] = audioFormat.language;
                }
            }
        }

        for (int periodIndex = 0; periodIndex < helper.getPeriodCount(); periodIndex++) {
            helper.clearTrackSelections(periodIndex);
            helper.addTrackSelection(periodIndex, parameters);
            helper.addAudioLanguagesToSelection(audioLanguages);
            SDKLogger.i("Applied track selections to period " + periodIndex);
        }
    }

    private Format findVideoFormatAtIndex(MappedTrackInfo mappedTrackInfo, int selectedTrackIndex) {
        int currentIndex = 0;

        for (int rendererIndex = 0; rendererIndex < mappedTrackInfo.getRendererCount(); rendererIndex++) {
            if (mappedTrackInfo.getRendererType(rendererIndex) != C.TRACK_TYPE_VIDEO) {
                continue;
            }

            TrackGroupArray trackGroups = mappedTrackInfo.getTrackGroups(rendererIndex);
            for (int groupIndex = 0; groupIndex < trackGroups.length; groupIndex++) {
                TrackGroup trackGroup = trackGroups.get(groupIndex);
                for (int trackIndex = 0; trackIndex < trackGroup.length; trackIndex++) {
                    if (currentIndex == selectedTrackIndex) {
                        return trackGroup.getFormat(trackIndex);
                    }
                    currentIndex++;
                }
            }
        }
        return null;
    }

    private List<Format> findAudioFormatsAtIndices(MappedTrackInfo mappedTrackInfo, int[] selectedIndices) {
        List<Format> formats = new ArrayList<>();
        int currentIndex = 0;

        for (int rendererIndex = 0; rendererIndex < mappedTrackInfo.getRendererCount(); rendererIndex++) {
            if (mappedTrackInfo.getRendererType(rendererIndex) != C.TRACK_TYPE_AUDIO) {
                continue;
            }

            TrackGroupArray trackGroups = mappedTrackInfo.getTrackGroups(rendererIndex);
            for (int groupIndex = 0; groupIndex < trackGroups.length; groupIndex++) {
                TrackGroup trackGroup = trackGroups.get(groupIndex);
                for (int trackIndex = 0; trackIndex < trackGroup.length; trackIndex++) {
                    for (int selectedIndex: selectedIndices) {
                        if (selectedIndex == currentIndex) {
                            formats.add(trackGroup.getFormat(trackIndex));
                        }
                    }
                    currentIndex++;
                }
            }
        }
        return formats;
    }

    private void extractTracksInfo(
            DownloadHelper helper,
            List<VideoTrack> videoTracks,
            List<AudioTrack> audioTracks
    ) {
        for (int periodIndex = 0; periodIndex < helper.getPeriodCount(); periodIndex++) {
            MappedTrackInfo mappedTrackInfo = helper.getMappedTrackInfo(periodIndex);

            for (int rendererIndex = 0; rendererIndex < mappedTrackInfo.getRendererCount(); rendererIndex++) {
                TrackGroupArray trackGroups = mappedTrackInfo.getTrackGroups(rendererIndex);
                int rendererType = mappedTrackInfo.getRendererType(rendererIndex);

                if (rendererType == C.TRACK_TYPE_VIDEO) {
                    for (int groupIndex = 0; groupIndex < trackGroups.length; groupIndex++) {
                        TrackGroup trackGroup = trackGroups.get(groupIndex);
                        for (int trackIndex = 0; trackIndex < trackGroup.length; trackIndex++) {
                            Format format = trackGroup.getFormat(trackIndex);
                            VideoTrack track = VideoTrack.init(format);
                            videoTracks.add(track);
                        }
                    }
                } else if (rendererType == C.TRACK_TYPE_AUDIO) {
                    for (int groupIndex = 0; groupIndex < trackGroups.length; groupIndex++) {
                        TrackGroup trackGroup = trackGroups.get(groupIndex);
                        for (int trackIndex = 0; trackIndex < trackGroup.length; trackIndex++) {
                            Format format = trackGroup.getFormat(trackIndex);
                            AudioTrack track = AudioTrack.init(format);
                            audioTracks.add(track);
                        }
                    }
                }
            }
        }
    }

    private void fetchOfflineLicenseThenDownload(
            DownloadHelper downloadHelper,
            DrmConfig drmConfig,
            String id,
            Downloader.OnDownloadErrorCallback callback
    ) {
        MediaItem.DrmConfiguration mediaItemDrmConfig = new MediaItem.DrmConfiguration.Builder(getDrmUuid(drmConfig.getDrmScheme()))
                .setLicenseUri(drmConfig.getLicenseUrl())
                .build();

        Format format = getVideoFormat(downloadHelper);
        if (format == null) {
            SDKLogger.e("No video format found for license fetch");
            startDownloadWithHelper(downloadHelper, null, id, null);
            return;
        }

        OfflineLicenseFetcher licenseFetcher = new OfflineLicenseFetcher(
                format,
                mediaItemDrmConfig,
                dataSourceFactory,
                new OfflineLicenseFetcher.Callback() {
                    @Override
                    public void onLicenseFetched(byte[] keySetId) {
                        SDKLogger.i("License fetched successfully for id: " + id);
                        activeLicenseFetchers.remove(id);
                        startDownloadWithHelper(downloadHelper, keySetId, id, drmConfig);
                    }

                    @Override
                    public void onLicenseFetchError(Exception error) {
                        SDKLogger.e("Failed to fetch license for id: " + id, error);
                        activeLicenseFetchers.remove(id);
                        downloadHelper.release();
                        if (callback != null) {
                            callback.onError(error);
                        }
                    }
                }
        );

        activeLicenseFetchers.put(id, licenseFetcher);
        licenseFetcher.execute();
    }

    private void startDownloadWithHelper(
            DownloadHelper helper,
            byte[] keySetId,
            String id,
            DrmConfig drmConfig
    ) {
        SDKLogger.d("startDownloadWithHelper called");
        SDKLogger.d("  id: " + id);
        SDKLogger.d("  keySetId: " + (keySetId != null ? Arrays.toString(keySetId) : "null"));

        Gson gson = new Gson();
        byte[] drmData = gson.toJson(drmConfig).getBytes(StandardCharsets.UTF_8);

        DownloadRequest downloadRequest;
        if (keySetId != null) {
            SDKLogger.i("Creating download request WITH keySetId");
            downloadRequest = helper.getDownloadRequest(id, drmData)
                    .copyWithKeySetId(keySetId);
        } else {
            SDKLogger.i("Creating download request WITHOUT keySetId");
            downloadRequest = helper.getDownloadRequest(id, drmData);
        }

        SDKLogger.d("Final downloadRequest.keySetId: " +
                (downloadRequest.keySetId != null ? Arrays.toString(downloadRequest.keySetId) : "null"));
        SDKLogger.d("Final downloadRequest.streamKeys.size: " + downloadRequest.streamKeys.size());

        DownloadService.sendAddDownload(
                appContext,
                downloadServiceClass,
                downloadRequest,
                false
        );
        helper.release();
        SDKLogger.i("Download started with id: " + id);
    }

    private Format getVideoFormat(DownloadHelper downloadHelper) {
        for (int periodIndex = 0; periodIndex < downloadHelper.getPeriodCount(); periodIndex++) {
            MappedTrackInfo mappedTrackInfo = downloadHelper.getMappedTrackInfo(periodIndex);
            for (int rendererIndex = 0; rendererIndex < mappedTrackInfo.getRendererCount(); rendererIndex++) {
                TrackGroupArray trackGroups = mappedTrackInfo.getTrackGroups(rendererIndex);
                for (int trackGroupIndex = 0; trackGroupIndex < trackGroups.length; trackGroupIndex++) {
                    TrackGroup trackGroup = trackGroups.get(trackGroupIndex);
                    for (int formatIndex = 0; formatIndex < trackGroup.length; formatIndex++) {
                        Format format = trackGroup.getFormat(formatIndex);
                        if (format.drmInitData != null) {
                            return format;
                        }
                    }
                }
            }
        }
        return null;
    }

    void removeDownloadById(String id) {
        androidx.media3.exoplayer.offline.Download download = downloads.get(id);
        if (download == null) {
            return;
        }

        // Cancel any active license fetch
        OfflineLicenseFetcher fetcher = activeLicenseFetchers.remove(id);
        if (fetcher != null) {
            fetcher.cancel();
        }

        thumbnailManager.deleteThumbnail(id);

        // Release license if present
        byte[] keySetId = download.request.keySetId;
        if (keySetId != null) {
            Uri requestUri = download.request.uri;
            // Build media item to get DRM config
            MediaItem mediaItem = new MediaItem.Builder()
                    .setUri(requestUri)
                    .build();

            MediaItem.LocalConfiguration localConfig = mediaItem.localConfiguration;
            if (localConfig != null && localConfig.drmConfiguration != null) {
                OfflineLicenseFetcher.releaseLicense(
                        keySetId,
                        localConfig.drmConfiguration,
                        dataSourceFactory
                );
            }
        }

        DownloadService.sendRemoveDownload(
                appContext,
                downloadServiceClass,
                download.request.id,
                false
        );

        downloadMetadataManager.remove(id);
        SDKLogger.i("Download removed by id: " + id);
    }

    private MediaItem buildMediaItemForDownload(DownloadConfig config) {
        MediaItem.Builder builder = new MediaItem.Builder()
                .setUri(config.getContentUrl());

        if (config.getDrmConfig() != null) {
            UUID drmUuid = getDrmUuid(config.getDrmConfig().getDrmScheme());
            builder.setDrmConfiguration(
                    new MediaItem.DrmConfiguration.Builder(drmUuid)
                            .setLicenseUri(config.getDrmConfig().getLicenseUrl())
                            .build()
            );
        }

        return builder.build();
    }

    private void loadDownloads() {
        try {
            DownloadCursor cursor = media3DownloadManager.getDownloadIndex().getDownloads();
            while (cursor.moveToNext()) {
                androidx.media3.exoplayer.offline.Download download = cursor.getDownload();
                downloads.put(download.request.id, download);
            }
            cursor.close();
        } catch (IOException e) {
            SDKLogger.e("Failed to load downloads", e);
        }
    }

    void release() {
        // Cancel all active license fetchers
        for (OfflineLicenseFetcher fetcher : activeLicenseFetchers.values()) {
            fetcher.cancel();
        }
        activeLicenseFetchers.clear();

        // Clear pending thumbnails
        pendingThumbnails.clear();

        // Release thumbnail manager
        thumbnailManager.release();
    }

    private long estimateManifestSizeForModel(DashManifest manifest, DownloadModel model) {
        VideoTrack selectedVideoTrack = model.getVideoTracks()[model.getSelectedVideoTrack()];
        AudioTrack[] selectedAudioTracks = null;
        if (model.getSelectedAudioTracks() != null) {
            selectedAudioTracks = new AudioTrack[model.getSelectedAudioTracks().length];

            for (int i = 0; i < model.getSelectedAudioTracks().length; i++) {
                int selectedTrackIdx = model.getSelectedAudioTracks()[i];
                AudioTrack selectedAudioTrack = model.getAudioTracks()[selectedTrackIdx];
                selectedAudioTracks[i] = selectedAudioTrack;
            }
        }

        long size = 0;
        try {
            for (int periodIndex = 0; periodIndex < manifest.getPeriodCount(); periodIndex++) {
                Period period = manifest.getPeriod(periodIndex);

                SDKLogger.i("manifest.durationMs: " + manifest.durationMs);
                long periodDurationSec = manifest.durationMs / 1000;

                // Calculate video size
                for (AdaptationSet adaptationSet : period.adaptationSets) {
                    if (adaptationSet.type == C.TRACK_TYPE_VIDEO) {
                        for (Representation rep: adaptationSet.representations) {
                            SDKLogger.i("rep bitrate: " + rep.format.bitrate + " || res: " + rep.format.width + "x" + rep.format.height);
                            if (rep.format.id != null && rep.format.id.equals(selectedVideoTrack.getId())) {
                                size += (rep.format.bitrate * periodDurationSec) / 8;
                            }
                        }
                    }

                    if (selectedAudioTracks != null) {
                        // Calculate audio size
                        if (adaptationSet.type == C.TRACK_TYPE_AUDIO) {
                            for (Representation audioRep: adaptationSet.representations) {
                                if (audioRep.format.id != null) {
                                    String id = audioRep.format.id;
                                    for (AudioTrack track: selectedAudioTracks) {
                                        if (track.getId().equals(id)) {
                                            size += (audioRep.format.bitrate * periodDurationSec) / 8;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            SDKLogger.e("Error calculating manifest size", e);
        }

        SDKLogger.d("manifest size: " + size);
        return size;
    }

    void pauseDownload(String id) {
        DownloadService.sendSetStopReason(appContext, downloadServiceClass, id, 1, false);
    }

    void resumeDownload(String id) {
        DownloadService.sendSetStopReason(appContext, downloadServiceClass, id, androidx.media3.exoplayer.offline.Download.STOP_REASON_NONE, false);
    }

    private class DownloadManagerListener implements androidx.media3.exoplayer.offline.DownloadManager.Listener {
        @Override
        public void onDownloadChanged(
                @NonNull androidx.media3.exoplayer.offline.DownloadManager downloadManager,
                androidx.media3.exoplayer.offline.Download download,
                Exception finalException
        ) {
            String id = download.request.id;
            downloads.put(id, download);
            if (finalException != null) {
                SDKLogger.e("Download error for id: " + id, finalException);
            }

            long estimatedSize = 0;
            for (DownloadMetadata metadata: downloadMetadataManager.getMetadataList()) {
                if (metadata.getId().equals(id)) {
                    estimatedSize = metadata.getEstimatedSize();
                }
            }

            Download myDownload = Download.fromDownload(download, estimatedSize);
            for (Listener listener : listeners) {
                listener.onDownloadsChanged();
                listener.onDownloadChanged(myDownload);
            }
        }

        @Override
        public void onDownloadRemoved(
                @NonNull androidx.media3.exoplayer.offline.DownloadManager downloadManager,
                androidx.media3.exoplayer.offline.Download download
        ) {
            String id = download.request.id;
            long estimatedSize = 0;
            for (DownloadMetadata metadata: downloadMetadataManager.getMetadataList()) {
                if (metadata.getId().equals(id)) {
                    estimatedSize = metadata.getEstimatedSize();
                }
            }
            downloads.remove(id);
            Download myDownload = Download.fromDownload(download, estimatedSize);
            for (Listener listener : listeners) {
                listener.onDownloadsChanged();
                listener.onDownloadRemoved(myDownload);
            }
        }
    }

    DownloadRequest getDownloadRequest(String id) {
        androidx.media3.exoplayer.offline.Download download = downloads.get(id);
        return download != null ? download.request : null;
    }
}