package com.hamburghini.playerplus.player.models;

import androidx.annotation.OptIn;
import androidx.media3.common.Format;
import androidx.media3.common.util.UnstableApi;

public class TextTrack {

    private final String language;
    private final String label;
    private final int selectionFlags;
    private final int roleFlags;
    private final String id;
    private final String mimeType;

    private TextTrack(
            String language,
            String label,
            int selectionFlags,
            int roleFlags,
            String id,
            String mimeType
    ) {
        this.language = language;
        this.label = label;
        this.selectionFlags = selectionFlags;
        this.roleFlags = roleFlags;
        this.id = id;
        this.mimeType = mimeType;
    }

    @OptIn(markerClass = UnstableApi.class)
    public static TextTrack init(Format format) {
        return new TextTrack(
                format.language,
                format.label,
                format.selectionFlags,
                format.roleFlags,
                format.id,
                format.sampleMimeType != null ? format.sampleMimeType : ""
        );
    }

    public String getLanguage() {
        return language;
    }

    public String getLabel() {
        return label;
    }

    public int getSelectionFlags() {
        return selectionFlags;
    }

    public int getRoleFlags() {
        return roleFlags;
    }

    public String getId() {
        return id;
    }

    public String getMimeType() {
        return mimeType;
    }

    @Override
    public String toString() {
        return "TextTrack(" +
                "language=" + language +
                ", label=" + label +
                ", selectionFlags=" + selectionFlags +
                ", roleFlags=" + roleFlags +
                ", id=" + id +
                ", mimeType=" + mimeType + ")";
    }
}