package com.hamburghini.playerplus.exceptions;

public class PluginNotRegisteredException extends RuntimeException {
    public PluginNotRegisteredException(String message) {
        super(message);
    }

    public PluginNotRegisteredException(String message, Throwable cause) {
        super(message, cause);
    }

    public PluginNotRegisteredException(Throwable cause) {
        super(cause);
    }
}
