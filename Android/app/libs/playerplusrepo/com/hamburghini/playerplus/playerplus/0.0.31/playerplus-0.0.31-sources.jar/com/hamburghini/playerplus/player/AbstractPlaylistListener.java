package com.hamburghini.playerplus.player;

import com.hamburghini.playerplus.player.configs.PlayerConfig;

public abstract class AbstractPlaylistListener implements PlaylistListener {
    @Override
    public void onItemChanged(PlayerConfig config) {}

    @Override
    public void onPlaylistEnded() {}
}
