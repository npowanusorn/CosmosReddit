package com.hamburghini.playerplus.download;

import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.scheduler.Requirements;

import java.util.ArrayList;
import java.util.List;

@OptIn(markerClass = UnstableApi.class)
public class DownloadRequirements {

    /**
     * Require network connectivity (any type)
     */
    public static final int NETWORK = Requirements.NETWORK;

    /**
     * Require non-metered network (WiFi)
     */
    public static final int NETWORK_UNMETERED = Requirements.NETWORK_UNMETERED;

    /**
     * Require device to be charging
     */
    public static final int DEVICE_CHARGING = Requirements.DEVICE_CHARGING;

    /**
     * Require device to be idle
     */
    public static final int DEVICE_IDLE = Requirements.DEVICE_IDLE;

    /**
     * Require sufficient storage space
     */
    public static final int DEVICE_STORAGE_NOT_LOW = Requirements.DEVICE_STORAGE_NOT_LOW;

    /**
     * No requirements - download under any conditions
     */
    public static final int NONE = 0;

    /**
     * Default requirements - network connectivity only
     */
    public static final int DEFAULT = NETWORK;

    /**
     * WiFi only - require unmetered network
     */
    public static final int WIFI_ONLY = NETWORK_UNMETERED;

    /**
     * WiFi and charging - require unmetered network and charging
     */
    public static final int WIFI_AND_CHARGING = NETWORK_UNMETERED | DEVICE_CHARGING;

    /**
     * All requirements - safest option
     */
    public static final int ALL = NETWORK_UNMETERED | DEVICE_CHARGING | DEVICE_IDLE | DEVICE_STORAGE_NOT_LOW;

    /**
     * Builder for custom requirements
     */
    public static class Builder {
        private int requirements = 0;

        public Builder requireNetwork(boolean require) {
            if (require) {
                requirements = requirements | NETWORK;
            } else {
                requirements = requirements & ~NETWORK;
            }
            return this;
        }

        public Builder requireNetwork() {
            return requireNetwork(true);
        }

        public Builder requireUnmeteredNetwork(boolean require) {
            if (require) {
                requirements = requirements | NETWORK_UNMETERED;
            } else {
                requirements = requirements & ~NETWORK_UNMETERED;
            }
            return this;
        }

        public Builder requireUnmeteredNetwork() {
            return requireUnmeteredNetwork(true);
        }

        public Builder requireCharging(boolean require) {
            if (require) {
                requirements = requirements | DEVICE_CHARGING;
            } else {
                requirements = requirements & ~DEVICE_CHARGING;
            }
            return this;
        }

        public Builder requireCharging() {
            return requireCharging(true);
        }

        public Builder requireIdle(boolean require) {
            if (require) {
                requirements = requirements | DEVICE_IDLE;
            } else {
                requirements = requirements & ~DEVICE_IDLE;
            }
            return this;
        }

        public Builder requireIdle() {
            return requireIdle(true);
        }

        public Builder requireStorageNotLow(boolean require) {
            if (require) {
                requirements = requirements | DEVICE_STORAGE_NOT_LOW;
            } else {
                requirements = requirements & ~DEVICE_STORAGE_NOT_LOW;
            }
            return this;
        }

        public Builder requireStorageNotLow() {
            return requireStorageNotLow(true);
        }

        public int build() {
            return requirements;
        }
    }

    /**
     * Check if requirements include network connectivity
     */
    public boolean hasNetworkRequirement(int requirements) {
        return (requirements & NETWORK) != 0;
    }

    /**
     * Check if requirements include unmetered network (WiFi)
     */
    public boolean hasUnmeteredNetworkRequirement(int requirements) {
        return (requirements & NETWORK_UNMETERED) != 0;
    }

    /**
     * Check if requirements include charging
     */
    public boolean hasChargingRequirement(int requirements) {
        return (requirements & DEVICE_CHARGING) != 0;
    }

    /**
     * Check if requirements include idle state
     */
    public boolean hasIdleRequirement(int requirements) {
        return (requirements & DEVICE_IDLE) != 0;
    }

    /**
     * Check if requirements include storage not low
     */
    public boolean hasStorageNotLowRequirement(int requirements) {
        return (requirements & DEVICE_STORAGE_NOT_LOW) != 0;
    }

    /**
     * Get human-readable requirements string
     */
    public String getRequirementsString(int requirements) {
        if (requirements == 0) {
            return "None";
        }

        List<String> parts = new ArrayList<>();

        if (hasUnmeteredNetworkRequirement(requirements)) {
            parts.add("WiFi");
        } else if (hasNetworkRequirement(requirements)) {
            parts.add("Network");
        }

        if (hasChargingRequirement(requirements)) {
            parts.add("Charging");
        }

        if (hasIdleRequirement(requirements)) {
            parts.add("Idle");
        }

        if (hasStorageNotLowRequirement(requirements)) {
            parts.add("Storage OK");
        }

        return String.join(", ", parts);
    }
}