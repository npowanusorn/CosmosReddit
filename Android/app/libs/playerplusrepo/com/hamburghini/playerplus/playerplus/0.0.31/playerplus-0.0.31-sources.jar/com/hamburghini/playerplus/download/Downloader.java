package com.hamburghini.playerplus.download;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.offline.DownloadRequest;

import com.hamburghini.playerplus.exceptions.PlayerPlusException;
import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.player.configs.DownloadConfig;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@OptIn(markerClass = UnstableApi.class)
public class Downloader {

    private static final long PROGRESS_UPDATE_INTERVAL = 500L;

    @SuppressLint("StaticFieldLeak")
    private static volatile Downloader instance;

    private final Context context;
    private final DownloadManager downloadManager;
    private final DownloadTracker downloadTracker;
    private final ThumbnailManager thumbnailManager;
    private final Handler progressHandler;
    private ProgressMonitorRunnable progressRunnable;
    private final Set<Listener> listeners = new HashSet<>();

    /**
     * Listener interface for download events
     */
    public interface Listener {
        /**
         * Called when any download changes
         */
        default void onDownloadsChanged() {}

        /**
         * Called periodically (every second) for active downloads
         * Use this for updating progress bars and download statistics
         */
        default void onDownloadProgress(Download download) {}

        /**
         * Called when a download completes
         */
        default void onDownloadCompleted(Download download) {}

        /**
         * Called when a download fails
         */
        default void onDownloadFailed(Download download, String error) {}

        /**
         * Called when a download is removed
         */
        default void onDownloadRemoved(String id) {}
    }

    public interface OnModelReadyCallback {
        void onException(Exception exception);
        void onModelAvailable(@NonNull DownloadModel model);
    }

    public interface OnDownloadErrorCallback {
        void onError(Exception exception);
    }

    private Downloader(Context context) {
        this.context = context.getApplicationContext();
        this.downloadManager = DownloadManager.getInstance(context);
        this.downloadTracker = DownloadTracker.getInstance(context);
        this.thumbnailManager = ThumbnailManager.getInstance(context);
        this.progressHandler = new Handler(Looper.getMainLooper());

        // Forward tracker events to our listeners
        downloadTracker.addListener(new DownloadTracker.Listener() {
            @Override
            public void onDownloadsChanged() {
                for (Listener listener : listeners) {
                    listener.onDownloadsChanged();
                }

                // Check if we need to start or stop progress monitoring
                updateProgressMonitoring();
            }

            @Override
            public void onDownloadChanged(Download download) {
                if (download.isCompleted()) {
                    for (Listener listener : listeners) {
                        listener.onDownloadCompleted(download);
                    }
                } else if (download.hasFailed()) {
                    for (Listener listener : listeners) {
                        listener.onDownloadFailed(download, download.getFailureReason());
                    }
                }
            }

            @Override
            public void onDownloadRemoved(Download download) {
                for (Listener listener : listeners) {
                    listener.onDownloadRemoved(download.getId());
                }
            }
        });

        // Check if there are ongoing downloads on initialization
        updateProgressMonitoring();
    }

    public static void initialize(Context context) {
        if (instance == null) {
            synchronized (Downloader.class) {
                if (instance == null) {
                    instance = new Downloader(context.getApplicationContext());
                }
            }
        }
    }

    public static Downloader getInstance() {
        if (instance == null) {
            throw new PlayerPlusException("Downloader not initialized");
        }
        return instance;
    }

    // ==================== Core Operations ====================

    /**
     * Prepare downloading a video
     *
     * @param config Configuration for the video to download
     */
    public void prepareDownload(DownloadConfig config, OnModelReadyCallback callback) {
        SDKLogger.d("prepareDownload: " + config.getContentUrl());
        downloadTracker.prepareDownload(config, callback);
    }

    /**
     * Start download
     * Call this after selected tracks in DownloadModel
     */
    public void startDownload(DownloadModel downloadModel, OnDownloadErrorCallback callback) {
        SDKLogger.d("startDownload: " + downloadModel);
        downloadTracker.startDownload(downloadModel, callback);

        startProgressMonitoring();
    }

    /**
     * Remove/cancel a download by id
     *
     * @param id User-defined id of the content to remove
     */
    public void remove(String id) {
        SDKLogger.d("Removing download by id: " + id);
        downloadTracker.removeDownloadById(id);
    }

    /**
     * Remove all downloads
     */
    public void removeAll() {
        SDKLogger.d("Removing all downloads");
        for (Download download : getAll()) {
            remove(download.getId());
        }
    }

    // ==================== Query Operations ====================

    /**
     * Check if content is downloaded by id
     *
     * @param id User-defined id of the content
     * @return true if downloaded and available offline
     */
    public boolean isDownloaded(String id) {
        return downloadTracker.isDownloadedById(id);
    }

    /**
     * Get download information by id
     *
     * @param id User-defined id of the content
     * @return MyDownload or null if not found
     */
    public Download get(String id) {
        return downloadTracker.getDownloadById(id);
    }

    /**
     * Get all downloads
     *
     * @return List of all downloads
     */
    public List<Download> getAll() {
        return downloadTracker.getAllDownloads();
    }

    /**
     * Get downloads by state
     *
     * @param state The download state to filter by
     * @return List of downloads in the specified state
     */
    public List<Download> getByState(Download.State state) {
        int downloadState = state.toMedia3State();
        return downloadTracker.getDownloadsByState(downloadState);
    }

    /**
     * Get completed downloads
     */
    public List<Download> getCompleted() {
        return getByState(Download.State.COMPLETED);
    }

    /**
     * Get in-progress downloads
     */
    public List<Download> getInProgress() {
        List<Download> result = new ArrayList<>();
        for (Download download : getAll()) {
            if (download.isInProgress()) {
                result.add(download);
            }
        }
        return result;
    }

    /**
     * Get failed downloads
     */
    public List<Download> getFailed() {
        return getByState(Download.State.FAILED);
    }

    /**
     * Get download progress percentage
     *
     * @param id User-defined id of the content
     * @return Progress from 0-100, or 0 if not found
     */
    public float getProgress(String id) {
        Download download = get(id);
        return download != null ? download.getProgress() : 0f;
    }

    // ==================== Thumbnail Operations ====================

    /**
     * Download and save a thumbnail for a download
     *
     * @param id User-defined id of the content
     * @param thumbnailUrl URL of the thumbnail image
     * @param callback Callback to notify when thumbnail is ready
     */
    public void downloadThumbnail(String id, String thumbnailUrl, ThumbnailManager.ThumbnailCallback callback) {
        thumbnailManager.downloadAndSaveThumbnail(id, thumbnailUrl, callback);
    }

    /**
     * Get thumbnail file path for a download
     *
     * @param id User-defined id of the content
     * @return File path or null if thumbnail doesn't exist
     */
    public String getThumbnailPath(String id) {
        return thumbnailManager.getThumbnailPath(id);
    }

    /**
     * Check if thumbnail exists for a download
     *
     * @param id User-defined id of the content
     * @return true if thumbnail exists
     */
    public boolean hasThumbnail(String id) {
        return thumbnailManager.hasThumbnail(id);
    }

    /**
     * Delete thumbnail for a download
     *
     * @param id User-defined id of the content
     * @return true if deletion was successful
     */
    public boolean deleteThumbnail(String id) {
        return thumbnailManager.deleteThumbnail(id);
    }

    /**
     * Get total size of all thumbnails in bytes
     */
    public long getTotalThumbnailSize() {
        return thumbnailManager.getTotalThumbnailSize();
    }

    /**
     * Delete all thumbnails
     */
    public boolean deleteAllThumbnails() {
        return thumbnailManager.deleteAllThumbnails();
    }

    // ==================== Control Operations ====================

    /**
     * Pause all downloads
     */
    public void pauseAll() {
        SDKLogger.d("Pausing all downloads");
        downloadManager.pauseDownloads();
    }

    public void pause(String id) {
        downloadTracker.pauseDownload(id);
    }

    /**
     * Resume all downloads
     */
    public void resumeAll() {
        SDKLogger.d("Resuming all downloads");
        downloadManager.resumeDownloads();
    }

    public void resume(String id) {
        downloadTracker.resumeDownload(id);
    }

    // ==================== Requirements ====================

    /**
     * Set download requirements (e.g., WiFi only, charging required)
     *
     * @param requirements Requirements flags
     * <p>
     * Examples:
     * <pre>
     * // WiFi only
     * downloader.setRequirements(DownloadRequirements.WIFI_ONLY);
     *
     * // WiFi and charging
     * downloader.setRequirements(DownloadRequirements.WIFI_AND_CHARGING);
     *
     * // Custom requirements
     * int requirements = new DownloadRequirements.Builder()
     *     .requireUnmeteredNetwork()
     *     .requireCharging()
     *     .build();
     * downloader.setRequirements(requirements);
     * </pre>
     */
    public void setRequirements(int requirements) {
        String reqString = new DownloadRequirements().getRequirementsString(requirements);
        SDKLogger.d("Setting requirements: " + reqString);
        downloadManager.setRequirements(requirements);
    }

    /**
     * Get current download requirements
     */
    public int getRequirements() {
        return downloadManager.getRequirements();
    }

    /**
     * Set WiFi only downloads
     */
    public void setWifiOnly(boolean enabled) {
        int requirements = enabled ? DownloadRequirements.WIFI_ONLY : DownloadRequirements.DEFAULT;
        setRequirements(requirements);
    }

    /**
     * Check if WiFi only is enabled
     */
    public boolean isWifiOnly() {
        return new DownloadRequirements().hasUnmeteredNetworkRequirement(getRequirements());
    }

    // ==================== Listener Management ====================

    /**
     * Add a download listener
     */
    public void addListener(Listener listener) {
        listeners.add(listener);
    }

    /**
     * Remove a download listener
     */
    public void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    /**
     * Remove all download listeners
     */
    public void clearListeners() {
        listeners.clear();
    }

    // ==================== Progress Monitoring ====================

    /**
     * Start monitoring download progress
     * Called automatically when downloads start
     */
    private void startProgressMonitoring() {
        if (progressRunnable == null) {
            SDKLogger.d("Starting progress monitoring");
            progressRunnable = new ProgressMonitorRunnable();
            progressHandler.post(progressRunnable);
        }
    }

    /**
     * Stop monitoring download progress
     * Called automatically when all downloads complete
     */
    private void stopProgressMonitoring() {
        if (progressRunnable != null) {
            SDKLogger.d("Stopping progress monitoring");
            progressHandler.removeCallbacks(progressRunnable);
            progressRunnable = null;
        }
    }

    /**
     * Check if we need to start or stop progress monitoring
     */
    private void updateProgressMonitoring() {
        boolean hasActiveDownloads = !getInProgress().isEmpty();

        if (hasActiveDownloads && progressRunnable == null) {
            startProgressMonitoring();
        } else if (!hasActiveDownloads && progressRunnable != null) {
            stopProgressMonitoring();
        }
    }

    /**
     * Runnable that monitors download progress periodically
     */
    private class ProgressMonitorRunnable implements Runnable {
        @Override
        public void run() {
            try {
                // Get all in-progress downloads
                List<Download> activeDownloads = getInProgress();

                if (activeDownloads.isEmpty()) {
                    // No more active downloads, stop monitoring
                    SDKLogger.d("No active downloads, stopping progress monitoring");
                    stopProgressMonitoring();
                    return;
                }

                // Notify listeners of progress for each active download
                for (Download download : activeDownloads) {
                    for (Listener listener : listeners) {
                        try {
                            listener.onDownloadProgress(download);
                        } catch (Exception e) {
                            SDKLogger.e("Error in progress listener", e);
                        }
                    }
                }

                // Schedule next update
                progressHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL);

            } catch (Exception e) {
                SDKLogger.e("Error in progress monitoring", e);
                // Try again anyway
                progressHandler.postDelayed(this, PROGRESS_UPDATE_INTERVAL);
            }
        }
    }

    // ==================== Advanced ====================

    /**
     * Get the data source factory for playing downloaded content
     * <p>
     * Use this when configuring a PlayerController to support offline playback:
     * <pre>
     * PlayerController playerController = new PlayerController(context);
     * playerController.setDataSourceFactory(downloader.getDataSourceFactory());
     * </pre>
     */
    public DataSource.Factory getDataSourceFactory() {
        return downloadManager.getDataSourceFactory();
    }

    /**
     * Release resources
     * Call this when you're completely done with downloads (e.g., app shutdown)
     */
    public void release() {
        stopProgressMonitoring();
        clearListeners();
        thumbnailManager.release();
        SDKLogger.d("Downloader released");
    }

    /**
     * Renew offline license for DRM content
     * Call this periodically for downloaded DRM content to keep licenses valid
     *
     * @param id User-defined id of the DRM content
     * @return true if renewal was successful
     */
    public boolean renewLicense(String id) {
        Download download = get(id);
        if (download == null) {
            return false;
        }

        if (!download.hasDrmLicense()) {
            SDKLogger.w("No DRM license to renew for id: " + id);
            return false;
        }

        byte[] keySetId = download.getKeySetId();
        if (keySetId == null) {
            return false;
        }

        // Build media item to get DRM config
        MediaItem mediaItem = new MediaItem.Builder()
                .setUri(download.getContentUrl())
                .build();

        MediaItem.DrmConfiguration drmConfig = mediaItem.localConfiguration != null
                ? mediaItem.localConfiguration.drmConfiguration
                : null;

        if (drmConfig == null) {
            SDKLogger.e("No DRM configuration found for id: " + id);
            return false;
        }

        DataSource.Factory dataSourceFactory = downloadManager.getDataSourceFactory();
        byte[] newKeySetId = OfflineLicenseFetcher.renewLicense(
                keySetId,
                drmConfig,
                dataSourceFactory
        );

        return newKeySetId != null;
    }

    /**
     * Check if content has a valid offline license
     *
     * @param id User-defined id of the content
     * @return true if content has an offline license
     */
    public boolean hasOfflineLicense(String id) {
        Download download = get(id);
        return download != null && download.hasDrmLicense();
    }

    public DownloadRequest getDownloadRequest(String id) {
        return downloadTracker.getDownloadRequest(id);
    }
}