package com.hamburghini.playerplus.player.configs;

public class AbrConfig {
    private final int maxInitialBitrate;

    public AbrConfig(int maxInitialBitrate) {
        this.maxInitialBitrate = maxInitialBitrate;
    }

    public int getMaxInitialBitrate() { return maxInitialBitrate; }
}
