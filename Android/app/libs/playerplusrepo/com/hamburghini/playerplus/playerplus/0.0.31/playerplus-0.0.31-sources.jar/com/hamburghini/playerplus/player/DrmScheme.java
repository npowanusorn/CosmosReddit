package com.hamburghini.playerplus.player;

public enum DrmScheme {
    WIDEVINE, CLEARKEY, PLAYREADY
}