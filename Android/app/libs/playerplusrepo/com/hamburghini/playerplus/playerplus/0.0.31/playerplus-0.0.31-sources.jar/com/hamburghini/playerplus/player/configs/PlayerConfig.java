package com.hamburghini.playerplus.player.configs;

import android.os.Bundle;

import java.util.HashMap;
import java.util.Map;

public class PlayerConfig {
    private final String contentUrl;
    private final DrmConfig drmConfig;
    private final AbrConfig abrConfig;
    private final long resumeTime;
    private final boolean playWhenReady;
    private final Bundle metadata;
    private final Map<String, String> header;
    private final String id;

    private PlayerConfig(Builder builder) {
        this.contentUrl = builder.contentUrl;
        this.drmConfig = builder.drmConfig;
        this.abrConfig = builder.abrConfig;
        this.resumeTime = builder.resumeTime;
        this.playWhenReady = builder.playWhenReady;
        this.metadata = builder.metadata;
        this.header = builder.header;
        this.id = builder.id;
    }

    // Getters
    public String getContentUrl() { return contentUrl; }
    public DrmConfig getDrmConfig() { return drmConfig; }
    public AbrConfig getAbrConfig() { return abrConfig; }
    public long getResumeTime() { return resumeTime; }
    public boolean isPlayWhenReady() { return playWhenReady; }
    public Bundle getMetadata() { return metadata; }
    public String getId() { return id; }
    public Map<String, String> getHeader() { return header; }

    /**
     * Builder for PlayerConfig
     */
    public static class Builder {
        private final String contentUrl;
        private DrmConfig drmConfig;
        private AbrConfig abrConfig;
        private long resumeTime = 0;
        private boolean playWhenReady = true;
        private Bundle metadata;
        private String id;
        private Map<String, String> header = new HashMap<>();

        /**
         * Create a builder with the required contentUrl
         * @param contentUrl URL of the content to play (required)
         */
        public Builder(String contentUrl) {
            if (contentUrl == null || contentUrl.isEmpty()) {
                throw new IllegalArgumentException("contentUrl cannot be null or empty");
            }
            this.contentUrl = contentUrl;
        }

        /**
         * Set DRM configuration
         * @param drmConfig DRM configuration for protected content
         */
        public Builder setDrmConfig(DrmConfig drmConfig) {
            this.drmConfig = drmConfig;
            return this;
        }

        /**
         * Set ABR configuration
         * @param abrConfig Adaptive bitrate configuration
         */
        public Builder setAbrConfig(AbrConfig abrConfig) {
            this.abrConfig = abrConfig;
            return this;
        }

        /**
         * Set resume time
         * @param resumeTime Time in milliseconds to resume playback from
         */
        public Builder setResumeTime(long resumeTime) {
            this.resumeTime = resumeTime;
            return this;
        }

        /**
         * Set whether to play when ready
         * @param playWhenReady If true, playback starts automatically when ready (default: true)
         */
        public Builder setPlayWhenReady(boolean playWhenReady) {
            this.playWhenReady = playWhenReady;
            return this;
        }

        /**
         * Set metadata bundle
         * @param metadata Custom metadata for the content
         */
        public Builder setMetadata(Bundle metadata) {
            this.metadata = metadata;
            return this;
        }

        /**
         * Set content ID
         * @param id Unique identifier for the content
         */
        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setHeader(Map<String, String> header) {
            this.header = header;
            return this;
        }

        /**
         * Build the PlayerConfig instance
         * @return Configured PlayerConfig
         */
        public PlayerConfig build() {
            return new PlayerConfig(this);
        }
    }
}
