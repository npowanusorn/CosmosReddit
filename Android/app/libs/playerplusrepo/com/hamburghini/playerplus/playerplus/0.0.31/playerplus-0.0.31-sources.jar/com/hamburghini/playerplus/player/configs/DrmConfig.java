package com.hamburghini.playerplus.player.configs;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;
import com.hamburghini.playerplus.player.DrmScheme;

public class DrmConfig {
    @SerializedName("licenseUrl")
    private final String licenseUrl;

    @SerializedName("drmScheme")
    private final DrmScheme drmScheme;

    @SerializedName("forceL3Widevine")
    private final boolean forceL3Widevine;

    private DrmConfig(Builder builder) {
        this.licenseUrl = builder.licenseUrl;
        this.drmScheme = builder.drmScheme;
        this.forceL3Widevine = builder.forceL3Widevine;
    }

    public String getLicenseUrl() {
        return licenseUrl;
    }

    public DrmScheme getDrmScheme() {
        return drmScheme;
    }

    public boolean isForceL3Widevine() {
        return forceL3Widevine;
    }

    public static class Builder {
        private final String licenseUrl;
        private final DrmScheme drmScheme;
        private boolean forceL3Widevine = false;

        public Builder(@NonNull String licenseUrl, @NonNull DrmScheme scheme) {
            this.licenseUrl = licenseUrl;
            this.drmScheme = scheme;
        }

        public Builder setForceL3Widevine(boolean forceL3Widevine) {
            this.forceL3Widevine = forceL3Widevine;
            return this;
        }

        public DrmConfig build() {
            return new DrmConfig(this);
        }
    }

    @NonNull
    @Override
    public String toString() {
        return "DrmConfig{" +
                "licenseUrl='" + licenseUrl + '\'' +
                ", drmScheme=" + drmScheme +
                ", forceL3Widevine=" + forceL3Widevine +
                '}';
    }
}
