package com.hamburghini.playerplus;

import android.content.Context;

import com.hamburghini.playerplus.download.DownloadMetadataManager;
import com.hamburghini.playerplus.plugin.Plugin;
import com.hamburghini.playerplus.plugin.PluginManager;

import java.util.ArrayList;
import java.util.List;

public class PlayerPlusSDK {

    private static boolean isInitialized = false;
    private static Context context;
    private static PluginManager pluginManager;

    /**
     * Initialize the SDK with default configuration
     *
     * @param ctx Application context
     */
    public static void initialize(Context ctx) {
        if (isInitialized) {
            SDKLogger.w("PlayerPlusSDK already initialized");
            return;
        }
        SDKLogger.i("Initialized PlayerPlusSDK v" + BuildConfig.LIBRARY_VERSION);
        isInitialized = true;
        context = ctx;

        DownloadMetadataManager.initialize(ctx);
        pluginManager = new PluginManager(ctx.getApplicationContext());
    }

    public static void register(Plugin plugin) {
        if (!isInitialized) {
            throw new IllegalStateException("PlayerPlusSDK not initialized");
        }

        pluginManager.register(plugin);
    }

    /**
     * Unregister a plugin from the SDK
     *
     * @param plugin Plugin to unregister
     */
    public static void unregister(Plugin plugin) {
        if (!isInitialized) {
            throw new IllegalStateException("PlayerPlusSDK not initialized");
        }

        pluginManager.unregister(plugin);
    }

    /**
     * Check if SDK is initialized
     */
    public static boolean isInitialized() {
        return isInitialized;
    }

    public static PluginManager getPluginManager() {
        return pluginManager;
    }
}