package com.hamburghini.playerplus.player;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.util.AttributeSet;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.ui.SubtitleView;

import com.hamburghini.playerplus.SDKLogger;

@OptIn(markerClass = UnstableApi.class)
public class PlayerView extends FrameLayout {

    private final androidx.media3.ui.PlayerView internalPlayerView;
    private PlayerController controller;
    private boolean isSecure = true;

    public PlayerView(@NonNull Context context) {
        this(context, null);
    }

    public PlayerView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PlayerView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        this.internalPlayerView = new androidx.media3.ui.PlayerView(context, attrs, defStyleAttr);
        this.controller = new PlayerController(context);

        addView(internalPlayerView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        internalPlayerView.setPlayer(controller.getPlayer());
        internalPlayerView.setUseController(false);
    }

    /**
     * Get the PlayerView's controller
     */
    public PlayerController getController() {
        return controller;
    }

    /**
     * Set a new PlayerController
     * This replaces the current controller and updates the underlying player
     */
    public void setController(PlayerController newController) {
        // Release the old controller if it's different
        if (controller != newController) {
            controller.destroy();
        }

        controller = newController;
        internalPlayerView.setPlayer(controller.getPlayer());
    }

    public void setSecureMode(boolean enabled) {
        isSecure = enabled;
        applySecureFlag();
    }

    public boolean isSecureMode() {
        return isSecure;
    }

    private void applySecureFlag() {
        Activity activity = findActivity(getContext());
        if (activity != null && activity.getWindow() != null) {
            if (isSecure) {
                activity.getWindow().setFlags(
                        WindowManager.LayoutParams.FLAG_SECURE,
                        WindowManager.LayoutParams.FLAG_SECURE
                );
            } else {
                activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            }
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (isSecure) {
            applySecureFlag();
        }
    }

    /**
     * Configure controller visibility timeout
     */
    public void setControllerTimeout(int timeoutMs) {
        internalPlayerView.setControllerShowTimeoutMs(timeoutMs);
    }

    /**
     * Show controller permanently
     */
    public void showControllerPermanently() {
        internalPlayerView.setControllerShowTimeoutMs(0);
    }

    /**
     * Show controller with default timeout
     */
    public void showControllerTemporarily() {
        internalPlayerView.showController();
    }

    /**
     * Hide controller
     */
    public void hideController() {
        internalPlayerView.hideController();
    }

    /**
     * Check if controller is visible
     */
    public boolean isControllerVisible() {
        return internalPlayerView.isControllerFullyVisible();
    }

    /**
     * Set whether to use controller
     */
    public void setUseController(boolean useController) {
        internalPlayerView.setUseController(useController);
    }

    /**
     * Release resources
     */
    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        // Note: We don't release the controller here as it might be used elsewhere
        // The controller should be released by the owning class
    }

    private static Activity findActivity(Context context) {
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity) context;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return null;
    }

    public void setSubtitleSize(SubtitleSize size) {
        SubtitleView subtitleView = internalPlayerView.getSubtitleView();
        SDKLogger.d("subtitleView is null: " + (subtitleView == null));
        if (subtitleView != null) {
            subtitleView.setApplyEmbeddedFontSizes(false);
            subtitleView.setFractionalTextSize(size.scale);
        }
    }
}