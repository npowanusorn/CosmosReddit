package com.hamburghini.playerplus.download;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;

import com.hamburghini.playerplus.player.configs.DrmConfig;

import java.util.Arrays;
import java.util.Objects;

public class Download {

    private final String id;
    private final String contentUrl;
    private final State state;
    private final float progress;
    private final long bytesDownloaded;
    private final long estimatedSize;
    private final String failureReason;
    private final byte[] keySetId;
    private final String thumbnailPath;
    private DrmConfig drmConfig;
    private final byte[] data;

    private Download(
            String id,
            String contentUrl,
            State state,
            float progress,
            long bytesDownloaded,
            long estimatedSize,
            String failureReason,
            byte[] keySetId,
            byte[] data,
            String thumbnailPath
    ) {
        this.id = id;
        this.contentUrl = contentUrl;
        this.state = state;
        this.progress = progress;
        this.bytesDownloaded = bytesDownloaded;
        this.failureReason = failureReason;
        this.keySetId = keySetId;
        this.thumbnailPath = thumbnailPath;
        this.estimatedSize = estimatedSize;
        this.data = data;
    }

    /**
     * Create MyDownload from Media3 Download (for tracking)
     */
    @OptIn(markerClass = UnstableApi.class)
    public static Download fromDownload(androidx.media3.exoplayer.offline.Download download, String thumbnailPath, long estimatedSize) {
        float progress;
        long size = estimatedSize;
        if (download.contentLength > 0) {
            size = download.contentLength;
            progress = ((float) download.getBytesDownloaded() / download.contentLength) * 100f;
        } else {
            progress = 0f;
        }

        State state;
        switch (download.state) {
            case androidx.media3.exoplayer.offline.Download.STATE_QUEUED:
                state = State.QUEUED;
                break;
            case androidx.media3.exoplayer.offline.Download.STATE_DOWNLOADING:
                state = State.DOWNLOADING;
                break;
            case androidx.media3.exoplayer.offline.Download.STATE_COMPLETED:
                state = State.COMPLETED;
                break;
            case androidx.media3.exoplayer.offline.Download.STATE_FAILED:
                state = State.FAILED;
                break;
            case androidx.media3.exoplayer.offline.Download.STATE_REMOVING:
                state = State.REMOVING;
                break;
            case androidx.media3.exoplayer.offline.Download.STATE_RESTARTING:
                state = State.RESTARTING;
                break;
            case androidx.media3.exoplayer.offline.Download.STATE_STOPPED:
                state = State.STOPPED;
                break;
            default:
                state = State.IDLE;
                break;
        }

        String failureReason = null;
        if (download.failureReason != androidx.media3.exoplayer.offline.Download.FAILURE_REASON_NONE) {
            failureReason = "Error code: " + download.failureReason;
        }

        DownloadMetadataManager metadataManager = DownloadMetadataManager.getInstance();
        DownloadMetadata metadata = metadataManager.get(download.request.id);
        byte[] data = null;
        if (metadata != null) data = metadata.getData();
        return new Download(
                download.request.id,
                download.request.uri.toString(),
                state,
                progress,
                download.getBytesDownloaded(),
                size,
                failureReason,
                download.request.keySetId,
                data,
                thumbnailPath
        );
    }

    @OptIn(markerClass = UnstableApi.class)
    public static Download fromDownload(androidx.media3.exoplayer.offline.Download download, long estimatedSize) {
        return fromDownload(download, null, estimatedSize);
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getContentUrl() {
        return contentUrl;
    }

    public State getState() {
        return state;
    }

    public float getProgress() {
        return progress;
    }

    public long getBytesDownloaded() {
        return bytesDownloaded;
    }

    public long getEstimatedSize() {
        return estimatedSize;
    }

    public String getFailureReason() {
        return failureReason;
    }

    public byte[] getKeySetId() {
        return keySetId;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }

    public DrmConfig getDrmConfig() {
        return drmConfig;
    }

    public byte[] getData() {
        return data;
    }

    void setDrmConfig(DrmConfig drmConfig) {
        this.drmConfig = drmConfig;
    }

    // Computed properties
    public boolean isCompleted() {
        return state == State.COMPLETED;
    }

    public boolean isInProgress() {
        return state == State.DOWNLOADING || state == State.QUEUED;
    }

    public boolean hasFailed() {
        return state == State.FAILED;
    }

    public boolean hasDrmLicense() {
        return keySetId != null;
    }

    public boolean isIdle() {
        return state == State.IDLE;
    }

    public boolean hasThumbnail() {
        return thumbnailPath != null;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Download other = (Download) obj;

        if (!contentUrl.equals(other.contentUrl)) return false;
        if (state != other.state) return false;
        if (Float.compare(other.progress, progress) != 0) return false;
        if (bytesDownloaded != other.bytesDownloaded) return false;
        if (!Objects.equals(failureReason, other.failureReason))
            return false;
        if (keySetId != null) {
            if (other.keySetId == null) return false;
            return Arrays.equals(keySetId, other.keySetId);
        } else return other.keySetId == null;
    }

    @Override
    public int hashCode() {
        int result = contentUrl.hashCode();
        result = 31 * result + state.hashCode();
        result = 31 * result + Float.hashCode(progress);
        result = 31 * result + Long.hashCode(bytesDownloaded);
        result = 31 * result + (failureReason != null ? failureReason.hashCode() : 0);
        result = 31 * result + (keySetId != null ? Arrays.hashCode(keySetId) : 0);
        return result;
    }

    @NonNull
    @Override
    public String toString() {
        return "Download{" +
                "id='" + id + '\'' +
                ", contentUrl='" + contentUrl + '\'' +
                ", state=" + state +
                ", progress=" + progress +
                ", bytesDownloaded=" + bytesDownloaded +
                '}';
    }

    public enum State {
        IDLE,
        QUEUED,
        DOWNLOADING,
        COMPLETED,
        FAILED,
        REMOVING,
        RESTARTING,
        STOPPED;

        @OptIn(markerClass = UnstableApi.class)
        public int toMedia3State() {
            switch (this) {
                case IDLE:
                    return -1;
                case QUEUED:
                    return androidx.media3.exoplayer.offline.Download.STATE_QUEUED;
                case DOWNLOADING:
                    return androidx.media3.exoplayer.offline.Download.STATE_DOWNLOADING;
                case COMPLETED:
                    return androidx.media3.exoplayer.offline.Download.STATE_COMPLETED;
                case FAILED:
                    return androidx.media3.exoplayer.offline.Download.STATE_FAILED;
                case REMOVING:
                    return androidx.media3.exoplayer.offline.Download.STATE_REMOVING;
                case RESTARTING:
                    return androidx.media3.exoplayer.offline.Download.STATE_RESTARTING;
                case STOPPED:
                    return androidx.media3.exoplayer.offline.Download.STATE_STOPPED;
                default:
                    return -1;
            }
        }
    }
}