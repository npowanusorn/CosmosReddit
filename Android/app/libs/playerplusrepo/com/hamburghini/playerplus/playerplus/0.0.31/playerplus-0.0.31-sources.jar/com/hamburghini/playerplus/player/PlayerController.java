package com.hamburghini.playerplus.player;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.VideoSize;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager;
import androidx.media3.exoplayer.drm.FrameworkMediaDrm;
import androidx.media3.exoplayer.drm.HttpMediaDrmCallback;
import androidx.media3.exoplayer.offline.DownloadRequest;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.exoplayer.upstream.CmcdConfiguration;

import com.hamburghini.playerplus.download.DownloadMetadata;
import com.hamburghini.playerplus.download.DownloadMetadataManager;
import com.hamburghini.playerplus.exceptions.PlayerPlusException;
import com.hamburghini.playerplus.PlayerPlusSDK;
import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.capabilities.AnalyticsCapability;
import com.hamburghini.playerplus.capabilities.CdnTrackingCapability;
import com.hamburghini.playerplus.capabilities.UserInfoTrackingCapability;
import com.hamburghini.playerplus.download.Downloader;
import com.hamburghini.playerplus.download.Download;
import com.hamburghini.playerplus.exceptions.PluginNotRegisteredException;
import com.hamburghini.playerplus.player.configs.DrmConfig;
import com.hamburghini.playerplus.player.configs.PlayerConfig;
import com.hamburghini.playerplus.player.models.AudioTrack;
import com.hamburghini.playerplus.player.models.TextTrack;
import com.hamburghini.playerplus.player.models.VideoTrack;
import com.hamburghini.playerplus.plugin.PluginManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@OptIn(markerClass = UnstableApi.class)
public class PlayerController {

    public interface OnCurrentTimeCallback {
        void onCurrentTime(long currentTime);
    }

    public enum State {
        IDLE(1),
        BUFFERING(2),
        READY(3),
        ENDED(4);

        private final int state;

        State(int state) {
            this.state = state;
        }

        public int getState() {
            return state;
        }

        public static State get(@Player.State int state) {
            switch (state) {
                case Player.STATE_BUFFERING:
                    return BUFFERING;
                case Player.STATE_READY:
                    return READY;
                case Player.STATE_ENDED:
                    return ENDED;
                default:
                    return IDLE;
            }
        }
    }

    @Nullable private ExoPlayer player = null;
    private final Context context;
    private PlayerListener playerListener;
    @Nullable private Downloader downloader;
    private double currentTimeCallbackRate = -1;
    private OnCurrentTimeCallback onCurrentTimeCallback = null;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable runnable;

    private final AnalyticsCapability analyticsCapability;
    private final PluginManager pluginManager;

    private final DownloadMetadataManager metadataManager = DownloadMetadataManager.getInstance();

    PlayerConfig playerConfig;
    Download currentDownload;

    public PlayerController(Context context) {
        this.context = context;

        try {
            this.downloader = Downloader.getInstance();
        } catch (PlayerPlusException e) {
            SDKLogger.d("Downloader not available - download features disabled");
            this.downloader = null;
        }

        pluginManager = PlayerPlusSDK.getPluginManager();
        analyticsCapability = pluginManager.getCapability(AnalyticsCapability.class);
    }

    public void addPlayerListener(PlayerListener listener) {
        this.playerListener = listener;
    }

    /**
     * Open and play content online (streaming mode)
     * This method forces streaming and ignores any downloaded content
     *
     * @param config PlayerConfig for the content to stream
     */
    public void open(PlayerConfig config) {
        if (player != null && player.isReleased()) {
            return;
        }

        SDKLogger.d("PlayerController.open() called for streaming");
        SDKLogger.d("  config.id: " + config.getId());
        SDKLogger.d("  config.contentUrl: " + config.getContentUrl());
        SDKLogger.d("  config.drmConfig: " + config.getDrmConfig());

        // Reset offline state
        currentDownload = null;

        // Create a new player instance for online streaming (without cache)
        configurePlayerForStreaming(config);

        // Always build online MediaItem (ignore downloads)
        MediaItem mediaItem = SDKUtils.buildMediaItem(config);

        playerConfig = config;
        player.setMediaItem(mediaItem);
        player.prepare();
        player.seekTo(config.getResumeTime());
        player.setPlayWhenReady(config.isPlayWhenReady());

        if (config.getAbrConfig() != null) {
            player.setTrackSelectionParameters(
                    player.getTrackSelectionParameters().buildUpon()
                            .setMaxVideoBitrate(config.getAbrConfig().getMaxInitialBitrate())
                            .build()
            );
        }

        SDKLogger.i("Opened content for streaming: " + config.getContentUrl());
    }

    /**
     * Open and play downloaded content (offline mode)
     * This method plays the offline downloaded content
     * DownloadPlugin must be registered
     *
     * @param download Download object containing the downloaded content info
     * @throws PluginNotRegisteredException If DownloadPlugin is not registered
     */
    public void open(Download download) {
        if (player != null && player.isReleased()) {
            return;
        }

        if (downloader == null) {
            SDKLogger.e("Cannot open download - DownloadPlugin not registered");
            throw new PluginNotRegisteredException("DownloadPlugin not registered");
        }

        SDKLogger.d("PlayerController.open() called for offline playback");
        SDKLogger.d("  download.id: " + download.getId());
        SDKLogger.d("  download.contentUrl: " + download.getContentUrl());
        SDKLogger.d("  download.hasDrmLicense: " + download.hasDrmLicense());

        // Reset online state
        playerConfig = null;
        currentDownload = download;

        // Ensure content is actually downloaded
        if (!download.isCompleted()) {
            SDKLogger.e("Cannot open download that is not completed. State: " + download.getState());
            if (playerListener != null) {
                playerListener.onPlayerError(
                        new PlayerPlusException(
                                "Download is not completed",
                                null
                        )
                );
            }
            return;
        }

        // Get the download request for offline MediaItem construction
        DownloadMetadata metadata = metadataManager.get(download.getId());
        DrmConfig drmConfig = metadata.getDrmConfig();
        DownloadRequest downloadRequest =
                downloader.getDownloadRequest(download.getId());

        // Create a new player instance for offline playback (with cache)
        configurePlayerForOffline(drmConfig);

        if (downloadRequest == null) {
            SDKLogger.e("DownloadRequest not found for offline content: " + download.getId());
            if (playerListener != null) {
                playerListener.onPlayerError(
                        new PlayerPlusException(
                                "Download request not found",
                                null
                        )
                );
            }
            return;
        }

        SDKLogger.d("  DownloadRequest found");
        SDKLogger.d("    downloadRequest.keySetId: " +
                (downloadRequest.keySetId != null ? Arrays.toString(downloadRequest.keySetId) : "null"));
        SDKLogger.d("    downloadRequest.streamKeys.size: " + downloadRequest.streamKeys.size());

        // Build offline MediaItem with downloaded content
        MediaItem.Builder builder = new MediaItem.Builder().setUri(download.getContentUrl());

        // Set stream keys from download request (for track selection)
        builder.setStreamKeys(downloadRequest.streamKeys);

        // If DRM is configured and we have an offline license, set it
        SDKLogger.d("drmConfig == null: " + (drmConfig == null));
        SDKLogger.d("downloadRequest.keySetId == null: " + (downloadRequest.keySetId == null));
        if (drmConfig != null && downloadRequest.keySetId != null) {
            SDKLogger.d("  Setting up offline DRM configuration");
            UUID drmUuid;
            switch (drmConfig.getDrmScheme()) {
                case WIDEVINE:
                    drmUuid = C.WIDEVINE_UUID;
                    break;
                case PLAYREADY:
                    drmUuid = C.PLAYREADY_UUID;
                    break;
                case CLEARKEY:
                    drmUuid = C.CLEARKEY_UUID;
                    break;
                default:
                    drmUuid = C.UUID_NIL;
                    break;
            }
            builder.setDrmConfiguration(
                    new MediaItem.DrmConfiguration.Builder(drmUuid)
                            .setLicenseUri(drmConfig.getLicenseUrl())
                            .setKeySetId(downloadRequest.keySetId)
                            .build()
            );
            SDKLogger.d("  Offline DRM configuration set with keySetId");
        } else if (download.getDrmConfig() != null) {
            SDKLogger.w("  DRM config present but no keySetId found!");
        }

        MediaItem mediaItem = builder.build();

        player.setMediaItem(mediaItem);
        player.prepare();
        player.setPlayWhenReady(true);

        SDKLogger.i("Opened downloaded content for offline playback: " + download.getId());
    }

    /**
     * Recreate player for streaming mode (without cache)
     */
    private void configurePlayerForStreaming(PlayerConfig config) {
        if (player != null) {
            release();
            destroy();
        }

        DefaultRenderersFactory renderersFactory = new DefaultRenderersFactory(context)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF);

        // Get CDN and user info capabilities
        CdnTrackingCapability cdnTrackingCapability = PlayerPlusSDK.getPluginManager().getCapability(CdnTrackingCapability.class);
        UserInfoTrackingCapability userInfoTrackingCapability = pluginManager.getCapability(UserInfoTrackingCapability.class);

        Map<String, String> userInfoMap;
        HttpDataSource.Factory httpDataSourceFactory;

        if (cdnTrackingCapability != null) {
            httpDataSourceFactory = cdnTrackingCapability.createDataSourceFactory();
        } else {
            httpDataSourceFactory = new DefaultHttpDataSource.Factory()
                    .setAllowCrossProtocolRedirects(true);
        }

        if (userInfoTrackingCapability == null) {
            userInfoMap = new HashMap<>();
        } else {
            userInfoMap = userInfoTrackingCapability.getUserInfo();
        }

        // Create data source factory with headers
        DataSource.Factory dataSourceFactory = () -> {
            HttpDataSource dataSource = httpDataSourceFactory.createDataSource();
            for (Map.Entry<String, String> entry : config.getHeader().entrySet()) {
                dataSource.setRequestProperty(entry.getKey(), entry.getValue());
            }
            for (Map.Entry<String, String> entry : userInfoMap.entrySet()) {
                dataSource.setRequestProperty(entry.getKey(), entry.getValue());
            }
            return dataSource;
        };

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(context);
        trackSelector.setParameters(
                trackSelector
                        .buildUponParameters()
                        .setPreferredVideoMimeType(MimeTypes.VIDEO_H264)
        );

        // Build the media source factory
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(context)
                .setDataSourceFactory(dataSourceFactory)
                .setCmcdConfigurationFactory(CmcdConfiguration.Factory.DEFAULT);

        // Only set up DRM if the content actually has DRM configuration
        if (config.getDrmConfig() != null) {
            SDKLogger.d("Setting up DRM for streaming with license URL: " + config.getDrmConfig().getLicenseUrl());

            String licenseUrl = config.getDrmConfig().getLicenseUrl();
            HttpMediaDrmCallback drmCallback = new HttpMediaDrmCallback(
                    licenseUrl,
                    new DefaultHttpDataSource.Factory()
            );

            // Determine DRM UUID from config
            UUID drmUuid;
            switch (config.getDrmConfig().getDrmScheme()) {
                case WIDEVINE:
                    drmUuid = C.WIDEVINE_UUID;
                    break;
                case PLAYREADY:
                    drmUuid = C.PLAYREADY_UUID;
                    break;
                case CLEARKEY:
                    drmUuid = C.CLEARKEY_UUID;
                    break;
                default:
                    drmUuid = C.UUID_NIL;
                    break;
            }

            DefaultDrmSessionManager drmSessionManager = new DefaultDrmSessionManager.Builder()
                    .setUuidAndExoMediaDrmProvider(drmUuid, uuid -> {
                        try {
                            FrameworkMediaDrm mediaDrm = FrameworkMediaDrm.newInstance(uuid);
                            // Force L3 by setting security level
                            mediaDrm.setPropertyString("securityLevel", "L3");
                            return mediaDrm;
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    })
                    .build(drmCallback);

            mediaSourceFactory.setDrmSessionManagerProvider(mediaItem -> drmSessionManager);
        } else {
            SDKLogger.d("No DRM configuration - playing clear content");
        }

        // Build the player
        player = new ExoPlayer.Builder(context)
                .setTrackSelector(trackSelector)
                .setRenderersFactory(renderersFactory)
                .setMediaSourceFactory(mediaSourceFactory)
                .build();

        player.addListener(createPlayerListener());
        if (analyticsCapability != null) {
            player.addAnalyticsListener(analyticsCapability.getAnalyticsListener());
        }
    }

    /**
     * Recreate player for offline mode
     */
    private void configurePlayerForOffline(DrmConfig drmConfig) {
        if (player != null) {
            release();
            destroy();
        }

        // Check if downloader is available
        if (downloader == null) {
            SDKLogger.e("Cannot configure player for offline - downloader not available");
            return;
        }

//        String licenseUrl = drmConfig.getLicenseUrl();
//
//        HttpMediaDrmCallback drmCallback = new HttpMediaDrmCallback(
//                licenseUrl,
//                new DefaultHttpDataSource.Factory()
//        );
//        DefaultRenderersFactory renderersFactory = new DefaultRenderersFactory(context)
//                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF);
//
//        DefaultDrmSessionManager drmSessionManager = new DefaultDrmSessionManager.Builder()
//                .setUuidAndExoMediaDrmProvider(C.WIDEVINE_UUID, uuid -> {
//                    try {
//                        FrameworkMediaDrm mediaDrm = FrameworkMediaDrm.newInstance(uuid);
//                        // Force L3 by setting software_crypto property
//                        mediaDrm.setPropertyString("securityLevel", "L3");
//                        return mediaDrm;
//                    } catch (Exception e) {
//                        throw new RuntimeException(e);
//                    }
//                })
//                .build(drmCallback);

        // Create player with cache data source factory
        player = new ExoPlayer.Builder(context)
                .setMediaSourceFactory(
                        new DefaultMediaSourceFactory(context)
                                .setDataSourceFactory(downloader.getDataSourceFactory())
//                                .setDrmSessionManagerProvider(mediaItem -> drmSessionManager)
                )
                .build();

        player.addListener(createPlayerListener());

        SDKLogger.d("Player recreated for offline mode");
    }

    /**
     * Create the player listener (extracted to avoid duplication)
     */
    private Player.Listener createPlayerListener() {
        return new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playerListener != null) {
                    playerListener.onPlaybackStateChanged(State.get(playbackState));
                }
            }

            @Override
            public void onPlayerError(@NonNull PlaybackException error) {
                if (playerListener != null) {
                    playerListener.onPlayerError(new PlayerPlusException(error.getErrorCodeName(), error.getCause()));
                }
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                if (playerListener != null) {
                    playerListener.onIsPlayingChanged(isPlaying);
                }
                if (isPlaying) {
                    startReportingCurrentTime();
                } else {
                    stopReportingCurrentTime();
                }
            }

            @Override
            public void onDeviceVolumeChanged(int volume, boolean muted) {
                if (playerListener != null) {
                    playerListener.onDeviceVolumeChanged(volume, muted);
                }
            }

            @Override
            public void onVolumeChanged(float volume) {
                if (playerListener != null) {
                    playerListener.onVolumeChanged(volume);
                }
            }

            @Override
            public void onVideoSizeChanged(@NonNull VideoSize videoSize) {
                if (playerListener != null) {
                    playerListener.onVideoSizeChanged(videoSize);
                }
            }
        };
    }

    /**
     * Play the current video
     */
    public void play() {
        if (player != null) {
            player.play();
        }
    }

    /**
     * Pause the current video
     */
    public void pause() {
        if (player != null) {
            player.pause();
        }
    }

    /**
     * Stop playback and reset player
     */
    public void stop() {
        if (player != null) {
            player.stop();
        }
    }

    /**
     * Seek to a specific position in milliseconds
     */
    public void seekTo(long positionMs) {
        if (player != null) {
            player.seekTo(positionMs);
        }
    }

    /**
     * Get current playback position in milliseconds
     */
    public long getCurrentPosition() {
        return player != null ? player.getCurrentPosition() : 0;
    }

    /**
     * Get total duration in milliseconds
     */
    public long getDuration() {
        return player != null ? player.getDuration() : 0;
    }

    /**
     * Check if player is currently playing
     */
    public boolean isPlaying() {
        return player != null && player.isPlaying();
    }

    /**
     * Set playback speed
     */
    public void setPlaybackSpeed(float speed) {
        if (player != null) {
            player.setPlaybackSpeed(speed);
        }
    }

    /**
     * Set volume (0.0 to 1.0)
     */
    public void setVolume(float volume) {
        if (player != null) {
            player.setVolume(Math.max(0f, Math.min(1f, volume)));
        }
    }

    /**
     * Get the underlying ExoPlayer instance for advanced usage
     */
    @Nullable
    public ExoPlayer getPlayer() {
        return player;
    }

    public State getState() {
        if (player == null) return State.IDLE;
        return State.get(player.getPlaybackState());
    }

    public void release() {
        if (player != null) {
            player.stop();
            player.clearMediaItems();
            player.clearVideoSurface();
            player.seekTo(0);
        }
    }

    public void destroy() {
        if (player != null) {
            player.release();
            playerListener = null;
        }
    }

    public PlayerConfig getPlayerConfig() {
        return playerConfig;
    }

    public Bundle getCurrentMetadata() {
        return playerConfig != null ? playerConfig.getMetadata() : null;
    }

    public void onCurrentTime(double rate, OnCurrentTimeCallback callback) {
        if (rate < 0.1) {
            throw new IllegalArgumentException("rate must be at least 0.1");
        }
        this.currentTimeCallbackRate = rate;
        this.onCurrentTimeCallback = callback;
    }

    private void startReportingCurrentTime() {
        if (player == null) return;
        if (runnable != null) return;

        runnable = new Runnable() {
            @Override
            public void run() {
                if (player.isPlaying() && onCurrentTimeCallback != null) {
                    long currentTimeMs = player.getCurrentPosition();
                    onCurrentTimeCallback.onCurrentTime(currentTimeMs);
                }
                handler.postDelayed(this, (long) (currentTimeCallbackRate * 1000.0));
            }
        };

        handler.post(runnable);
    }

    private void stopReportingCurrentTime() {
        if (runnable != null) {
            handler.removeCallbacks(runnable);
            runnable = null;
        }
    }

    public List<AudioTrack> getAudioTracks() {
        if (player == null) return new ArrayList<>();
        List<AudioTrack> tracks = new ArrayList<>();
        for (int i = 0; i < player.getCurrentTracks().getGroups().size(); i++) {
            Tracks.Group group = player.getCurrentTracks().getGroups().get(i);
            @C.TrackType int trackType = group.getType();
            if (trackType == C.TRACK_TYPE_AUDIO) {
                for (int j = 0; j < group.length; j++) {
                    Format format = group.getTrackFormat(j);
                    AudioTrack audioTrack = AudioTrack.init(format);
                    tracks.add(audioTrack);
                }
            }
        }
        return tracks;
    }

    public List<VideoTrack> getVideoTracks() {
        if (player == null) return new ArrayList<>();
        List<VideoTrack> tracks = new ArrayList<>();
        for (int i = 0; i < player.getCurrentTracks().getGroups().size(); i++) {
            Tracks.Group group = player.getCurrentTracks().getGroups().get(i);
            @C.TrackType int trackType = group.getType();
            if (trackType == C.TRACK_TYPE_VIDEO) {
                for (int j = 0; j < group.length; j++) {
                    Format format = group.getTrackFormat(j);
                    VideoTrack videoTrack = VideoTrack.init(format);
                    tracks.add(videoTrack);
                }
            }
        }
        return tracks;
    }

    public List<TextTrack> getTextTracks() {
        if (player == null) return new ArrayList<>();
        List<TextTrack> tracks = new ArrayList<>();
        for (int i = 0; i < player.getCurrentTracks().getGroups().size(); i++) {
            Tracks.Group group = player.getCurrentTracks().getGroups().get(i);
            @C.TrackType int trackType = group.getType();
            if (trackType == C.TRACK_TYPE_TEXT) {
                for (int j = 0; j < group.length; j++) {
                    Format format = group.getTrackFormat(j);
                    TextTrack videoTrack = TextTrack.init(format);
                    tracks.add(videoTrack);
                }
            }
        }
        return tracks;
    }

    @Nullable
    public AudioTrack getAudioTrack() {
        if (player == null) return null;
        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group group: tracks.getGroups()) {
            if (group.getType() == C.TRACK_TYPE_AUDIO) {
                for (int i = 0; i < group.length; i++) {
                    if (group.isTrackSelected(i)) {
                        Format format = group.getTrackFormat(i);
                        return AudioTrack.init(format);
                    }
                }
            }
        }
        return null;
    }

    @Nullable
    public VideoTrack getVideoTrack() {
        if (player == null) return null;
        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() == C.TRACK_TYPE_VIDEO) {
                for (int i = 0; i < group.length; i++) {
                    if (group.isTrackSelected(i)) {
                        Format format = group.getTrackFormat(i);
                        return VideoTrack.init(format);
                    }
                }
            }
        }
        return null;
    }

    @Nullable
    public TextTrack getTextTrack() {
        if (player == null) return null;
        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() == C.TRACK_TYPE_TEXT) {
                for (int i = 0; i < group.length; i++) {
                    if (group.isTrackSelected(i)) {
                        Format format = group.getTrackFormat(i);
                        return TextTrack.init(format);
                    }
                }
            }
        }
        return null;
    }

    public void setAudioTrack(@NonNull AudioTrack audioTrack) {
        if (player == null) return;
        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group trackGroup: tracks.getGroups()) {
            if (trackGroup.getType() == C.TRACK_TYPE_AUDIO) {
                for (int i = 0; i < trackGroup.length; i++) {
                    Format format = trackGroup.getTrackFormat(i);
                    if (SDKUtils.equals(format.id, audioTrack.getId())) {
                        TrackSelectionParameters.Builder builder = player.getTrackSelectionParameters().buildUpon();
                        TrackSelectionOverride override = new TrackSelectionOverride(trackGroup.getMediaTrackGroup(), i);
                        builder.setOverrideForType(override);
                        player.setTrackSelectionParameters(builder.build());
                        return;
                    }
                }
            }
        }
    }

    public void setVideoTrack(@Nullable VideoTrack videoTrack) {
        if (player == null) return;
        if (videoTrack == null) {
            player.setTrackSelectionParameters(
                    player.getTrackSelectionParameters()
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
                            .build()
            );
            return;
        }
        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group trackGroup: tracks.getGroups()) {
            if (trackGroup.getType() == C.TRACK_TYPE_VIDEO) {
                for (int i = 0; i < trackGroup.length; i++) {
                    Format format = trackGroup.getTrackFormat(i);
                    if (SDKUtils.equals(format.id, videoTrack.getId())) {
                        TrackSelectionParameters.Builder builder = player.getTrackSelectionParameters().buildUpon();
                        TrackSelectionOverride override = new TrackSelectionOverride(trackGroup.getMediaTrackGroup(), i);
                        builder.setOverrideForType(override);
                        player.setTrackSelectionParameters(builder.build());
                        return;
                    }
                }
            }
        }
    }

    public void setTextTrack(@Nullable TextTrack textTrack) {
        if (player == null) return;
        if (textTrack == null) {
            player.setTrackSelectionParameters(
                    player.getTrackSelectionParameters()
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                            .build()
            );
            return;
        }
        player.setTrackSelectionParameters(
                player.getTrackSelectionParameters()
                        .buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                        .build()
        );
        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group trackGroup: tracks.getGroups()) {
            if (trackGroup.getType() == C.TRACK_TYPE_TEXT) {
                for (int i = 0; i < trackGroup.length; i++) {
                    Format format = trackGroup.getTrackFormat(i);
                    if (SDKUtils.equals(format.id, textTrack.getId())) {
                        TrackSelectionParameters.Builder builder = player.getTrackSelectionParameters().buildUpon();
                        TrackSelectionOverride override = new TrackSelectionOverride(trackGroup.getMediaTrackGroup(), i);
                        builder.setOverrideForType(override);
                        player.setTrackSelectionParameters(builder.build());
                        return;
                    }
                }
            }
        }
    }

    public void skipForward(long duration) {
        if (player == null) return;
        player.seekTo(Math.min(getCurrentPosition() + duration, getDuration()));
    }

    public void skipBackward(long duration) {
        if (player == null) return;
        player.seekTo(Math.max(getCurrentPosition() - duration, 0));
    }

}