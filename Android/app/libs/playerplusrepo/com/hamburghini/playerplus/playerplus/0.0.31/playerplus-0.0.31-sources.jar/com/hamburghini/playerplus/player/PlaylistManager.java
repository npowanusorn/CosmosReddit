package com.hamburghini.playerplus.player;

import com.hamburghini.playerplus.player.configs.PlayerConfig;
import com.hamburghini.playerplus.player.configs.PlaylistConfig;

import java.util.ArrayList;
import java.util.List;

public class PlaylistManager {

    private final PlayerController playerController;
    private List<PlayerConfig> playlist = new ArrayList<>();
    private int currentIndex = 0;

    public PlaylistManager(PlayerController playerController) {
        this.playerController = playerController;
    }

    public void loadPlaylist(PlaylistConfig config) {
        playlist = new ArrayList<>(config.getItems());
        currentIndex = 0;

        if (!playlist.isEmpty()) {
            playerController.open(playlist.get(currentIndex));
        }
    }

    public boolean next() {
        if (currentIndex < playlist.size() - 1) {
            currentIndex++;
            playerController.open(playlist.get(currentIndex));
            return true;
        }
        return false;
    }

    public boolean previous() {
        if (currentIndex > 0) {
            currentIndex--;
            playerController.open(playlist.get(currentIndex));
            return true;
        }
        return false;
    }

    public boolean skipTo(int index) {
        if (index >= 0 && index < playlist.size()) {
            currentIndex = index;
            playerController.open(playlist.get(currentIndex));
            return true;
        }
        return false;
    }

    public PlayerConfig getCurrentItem() {
        if (currentIndex >= 0 && currentIndex < playlist.size()) {
            return playlist.get(currentIndex);
        }
        return null;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public int getPlaylistSize() {
        return playlist.size();
    }
}