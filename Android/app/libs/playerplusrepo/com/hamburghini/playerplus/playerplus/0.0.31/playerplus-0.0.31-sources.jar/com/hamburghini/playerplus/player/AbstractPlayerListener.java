package com.hamburghini.playerplus.player;

import androidx.media3.common.PlaybackException;
import androidx.media3.common.VideoSize;

import com.hamburghini.playerplus.exceptions.PlayerPlusException;

public class AbstractPlayerListener implements PlayerListener {
    @Override
    public void onPlaybackStateChanged(PlayerController.State state) {}

    @Override
    public void onPlayerError(PlayerPlusException error) {}

    @Override
    public void onIsPlayingChanged(boolean isPlaying) {}

    @Override
    public void onVolumeChanged(float volume) {}

    @Override
    public void onDeviceVolumeChanged(int volume, boolean muted) {}

    @Override
    public void onVideoSizeChanged(VideoSize videoSize) {}
}
