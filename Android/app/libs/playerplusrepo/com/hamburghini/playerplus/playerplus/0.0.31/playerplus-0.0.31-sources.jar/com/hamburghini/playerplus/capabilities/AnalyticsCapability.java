package com.hamburghini.playerplus.capabilities;

import androidx.media3.common.PlaybackException;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.analytics.AnalyticsListener;

import com.hamburghini.playerplus.player.PlayerController;
import com.hamburghini.playerplus.player.PlayerEventListener;

public interface AnalyticsCapability {
    AnalyticsListener getAnalyticsListener();
}