package com.hamburghini.playerplus.exceptions;

public class PlayerPlusException extends RuntimeException {
    public PlayerPlusException(String message) {
        super(message);
    }

    public PlayerPlusException(String message, Throwable cause) {
        super(message, cause);
    }

    public PlayerPlusException(Throwable cause) {
        super(cause);
    }
}
