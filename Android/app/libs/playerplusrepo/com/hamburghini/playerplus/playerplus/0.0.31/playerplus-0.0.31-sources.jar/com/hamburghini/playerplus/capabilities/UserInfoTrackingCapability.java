package com.hamburghini.playerplus.capabilities;

import java.util.Map;

public interface UserInfoTrackingCapability {
    Map<String, String> getUserInfo();
}
