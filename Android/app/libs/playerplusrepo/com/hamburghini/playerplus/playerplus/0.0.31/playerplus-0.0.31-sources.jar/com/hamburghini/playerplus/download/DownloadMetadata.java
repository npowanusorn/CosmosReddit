package com.hamburghini.playerplus.download;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.hamburghini.playerplus.player.configs.DrmConfig;

public class DownloadMetadata {
    private final String id;
    private final DrmConfig drmConfig;
    private final long estimatedSize;
    private final byte[] data;

    public DownloadMetadata(
            String id,
            DrmConfig drmConfig,
            long estimatedSize,
            byte[] data
    ) {
        this.drmConfig = drmConfig;
        this.id = id;
        this.estimatedSize = estimatedSize;
        this.data = data;
    }
    public DrmConfig getDrmConfig() {
        return drmConfig;
    }

    public String getId() {
        return id;
    }

    public long getEstimatedSize() {
        return estimatedSize;
    }

    public byte[] getData() {
        return data;
    }

    @NonNull
    @Override
    public String toString() {
        return "MediaMetadata{" +
                ", drmConfig=" + drmConfig +
                ", id='" + id + '\'' +
                ", estimatedSize=" + estimatedSize +
                '}';
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof DownloadMetadata)) return false;

        DownloadMetadata that = (DownloadMetadata) obj;

        return id != null && id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
