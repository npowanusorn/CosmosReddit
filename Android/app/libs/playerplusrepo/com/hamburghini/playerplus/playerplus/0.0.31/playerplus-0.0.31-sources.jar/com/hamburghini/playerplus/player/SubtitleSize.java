package com.hamburghini.playerplus.player;

public enum SubtitleSize {
    SMALL(0.035f),
    MEDIUM(0.05f),
    LARGE(0.07f);

    public final float scale;

    SubtitleSize(float scale) {
        this.scale = scale;
    }
}
