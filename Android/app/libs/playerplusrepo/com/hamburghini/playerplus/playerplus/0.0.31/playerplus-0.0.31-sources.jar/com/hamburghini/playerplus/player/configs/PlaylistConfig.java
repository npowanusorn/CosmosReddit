package com.hamburghini.playerplus.player.configs;

import androidx.annotation.NonNull;

import com.hamburghini.playerplus.player.RepeatMode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PlaylistConfig {
    private final List<PlayerConfig> items;
    private final RepeatMode repeatMode;
    private final boolean shuffle;
    private final int startIndex;

    private PlaylistConfig(Builder builder) {
        this.items = new ArrayList<>(builder.items);
        this.repeatMode = builder.repeatMode;
        this.shuffle = builder.shuffle;
        this.startIndex = builder.startIndex;
    }

    public List<PlayerConfig> getItems() { return items; }
    public RepeatMode getRepeatMode() { return repeatMode; }
    public boolean isShuffle() { return shuffle; }
    public int getStartIndex() { return startIndex; }

    /**
     * Builder for PlaylistConfig
     */
    public static class Builder {
        private final List<PlayerConfig> items;
        private RepeatMode repeatMode = RepeatMode.OFF;
        private boolean shuffle = false;
        private int startIndex = 0;

        /**
         * Create a builder with a list of items
         * @param items List of PlayerConfig items
         */
        public Builder(@NonNull List<PlayerConfig> items) {
            if (items.isEmpty()) {
                throw new IllegalArgumentException("items cannot be null or empty");
            }
            for (PlayerConfig item : items) {
                if (item == null) {
                    throw new IllegalArgumentException("item in items cannot be null");
                }
            }
            this.items = new ArrayList<>(items);
        }

        /**
         * Create a builder with a list of items
         * @param items PlayerConfig items
         */
        public Builder(@NonNull PlayerConfig... items) {
            this(Arrays.asList(items));
        }

        /**
         * Add a single item to the playlist
         * @param item PlayerConfig to add
         */
        public Builder addItem(@NonNull PlayerConfig item) {
            this.items.add(item);
            return this;
        }

        /**
         * Add multiple items to the playlist (varargs)
         * @param items PlayerConfig items to add
         */
        public Builder addItems(@NonNull PlayerConfig... items) {
            for (PlayerConfig item : items) {
                if (item == null) {
                    throw new IllegalArgumentException("item in items cannot be null");
                }
            }
            this.items.addAll(Arrays.asList(items));
            return this;
        }

        /**
         * Add multiple items to the playlist (list)
         * @param items List of PlayerConfig items to add
         */
        public Builder addItems(@NonNull List<PlayerConfig> items) {
            for (PlayerConfig item : items) {
                if (item == null) {
                    throw new IllegalArgumentException("item in items cannot be null");
                }
            }
            this.items.addAll(items);
            return this;
        }

        /**
         * Set the repeat mode
         * @param repeatMode Repeat mode (OFF, ONE, ALL). Default: OFF
         */
        public Builder setRepeatMode(@NonNull RepeatMode repeatMode) {
            this.repeatMode = repeatMode;
            return this;
        }

        /**
         * Set shuffle mode
         * @param shuffle True to enable shuffle. Default: false
         */
        public Builder setShuffle(boolean shuffle) {
            this.shuffle = shuffle;
            return this;
        }

        /**
         * Set the starting index
         * @param startIndex Index of the item to start playback from (0-based). Default: 0
         */
        public Builder setStartIndex(int startIndex) {
            if (startIndex < 0) {
                throw new IllegalArgumentException("startIndex cannot be negative");
            }
            this.startIndex = startIndex;
            return this;
        }

        /**
         * Build the PlaylistConfig instance
         * @return Configured PlaylistConfig
         * @throws IllegalStateException if startIndex is out of bounds
         */
        public PlaylistConfig build() {
            if (startIndex >= items.size()) {
                throw new IllegalStateException(
                        "startIndex (" + startIndex + ") must be less than playlist size (" + items.size() + ")"
                );
            }
            return new PlaylistConfig(this);
        }
    }
}
