package com.hamburghini.playerplus.player.configs;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class DownloadConfig {
    private final String contentUrl;
    private final DrmConfig drmConfig;
    private final String id;
    private final String thumbnailUrl;
    private final ContentType contentType;
    private final byte[] data;

    /**
     * Content type hint for download detection
     */
    public enum ContentType {
        /** Let SDK automatically detect content type (default) */
        AUTO,
        /** Force progressive download (MP4, MKV, WebM) */
        PROGRESSIVE,
        /** Force adaptive streaming (DASH, HLS, SmoothStreaming) */
        ADAPTIVE
    }

    private DownloadConfig(Builder builder) {
        this.contentUrl = builder.contentUrl;
        this.drmConfig = builder.drmConfig;
        this.id = builder.id;
        this.thumbnailUrl = builder.thumbnailUrl;
        this.contentType = builder.contentType;
        this.data = builder.data;
    }

    public String getContentUrl() { return contentUrl; }
    public DrmConfig getDrmConfig() { return drmConfig; }
    public String getId() { return id; }
    public String getThumbnailUrl() { return thumbnailUrl; }
    public ContentType getContentType() { return contentType; }
    public byte[] getData() { return data; }

    /**
     * Builder for DownloadConfig
     */
    public static class Builder {
        private final String contentUrl;
        private final String id;
        private DrmConfig drmConfig;
        private String thumbnailUrl;
        private ContentType contentType = ContentType.AUTO;
        private byte[] data;

        /**
         * Create a builder with required parameters
         * @param contentUrl URL of the content to download (required)
         * @param id Unique identifier for the download (required)
         */
        public Builder(@NonNull String contentUrl, @NonNull String id) {
            if (contentUrl.isEmpty()) {
                throw new IllegalArgumentException("contentUrl cannot be null or empty");
            }
            if (id.isEmpty()) {
                throw new IllegalArgumentException("id cannot be null or empty");
            }
            this.contentUrl = contentUrl;
            this.id = id;
        }

        /**
         * Set DRM configuration
         * @param drmConfig DRM configuration for protected content
         */
        public Builder setDrmConfig(@Nullable DrmConfig drmConfig) {
            this.drmConfig = drmConfig;
            return this;
        }

        /**
         * Set thumbnail URL
         * @param thumbnailUrl URL of the thumbnail image to download alongside the video
         */
        public Builder setThumbnailUrl(@Nullable String thumbnailUrl) {
            this.thumbnailUrl = thumbnailUrl;
            return this;
        }

        /**
         * Set content type hint to override automatic detection
         * Use this when you know the content type and want to skip detection
         *
         * @param contentType Content type (AUTO, PROGRESSIVE, or ADAPTIVE)
         *
         * Examples:
         * <pre>
         * // Force MP4 download for ambiguous API URL
         * .setContentType(DownloadConfig.ContentType.PROGRESSIVE)
         *
         * // Force DASH download
         * .setContentType(DownloadConfig.ContentType.ADAPTIVE)
         *
         * // Auto-detect (default)
         * .setContentType(DownloadConfig.ContentType.AUTO)
         * </pre>
         */
        public Builder setContentType(@NonNull ContentType contentType) {
            this.contentType = contentType;
            return this;
        }

        /**
         * Set data
         * @param data Additional data for this download (ie. title)
         */
        public Builder setData(@NonNull byte[] data) {
            this.data = data;
            return this;
        }

        /**
         * Build the DownloadConfig instance
         * @return Configured DownloadConfig
         */
        public DownloadConfig build() {
            return new DownloadConfig(this);
        }
    }
}