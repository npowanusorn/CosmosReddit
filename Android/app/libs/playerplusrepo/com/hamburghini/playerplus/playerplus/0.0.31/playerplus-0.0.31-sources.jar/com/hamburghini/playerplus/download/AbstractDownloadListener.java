package com.hamburghini.playerplus.download;

public class AbstractDownloadListener implements Downloader.Listener {
    @Override
    public void onDownloadRemoved(String id) {}

    @Override
    public void onDownloadFailed(Download download, String error) {}

    @Override
    public void onDownloadCompleted(Download download) {}

    @Override
    public void onDownloadProgress(Download download) {}

    @Override
    public void onDownloadsChanged() {}
}
