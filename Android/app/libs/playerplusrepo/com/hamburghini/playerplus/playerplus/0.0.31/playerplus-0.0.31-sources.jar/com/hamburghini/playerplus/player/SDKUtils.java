package com.hamburghini.playerplus.player;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;

import com.hamburghini.playerplus.player.configs.PlayerConfig;

import java.util.UUID;

class SDKUtils {
    protected static MediaItem buildMediaItem(PlayerConfig config) {
        MediaItem.Builder builder = new MediaItem.Builder().setUri(config.getContentUrl());

        if (config.getDrmConfig() != null) {
            UUID drmUuid;
            switch (config.getDrmConfig().getDrmScheme()) {
                case WIDEVINE:
                    drmUuid = C.WIDEVINE_UUID;
                    break;
                case PLAYREADY:
                    drmUuid = C.PLAYREADY_UUID;
                    break;
                case CLEARKEY:
                    drmUuid = C.CLEARKEY_UUID;
                    break;
                default:
                    throw new IllegalArgumentException("Unknown DRM scheme");
            }
            builder.setDrmConfiguration(
                    new MediaItem.DrmConfiguration.Builder(drmUuid)
                            .setLicenseUri(config.getDrmConfig().getLicenseUrl())
                            .build()
            );
        }

        return builder.build();
    }

    protected static boolean equals(@Nullable String s1, @Nullable String s2) {
        if (s1 == null || s2 == null) return false;
        return s1.equals(s2);
    }
}
