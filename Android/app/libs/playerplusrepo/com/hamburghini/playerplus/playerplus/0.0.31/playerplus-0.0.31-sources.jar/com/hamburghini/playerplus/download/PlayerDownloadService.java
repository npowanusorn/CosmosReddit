package com.hamburghini.playerplus.download;

import android.app.Notification;

import androidx.annotation.OptIn;
import androidx.core.app.NotificationCompat;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.offline.Download;
import androidx.media3.exoplayer.offline.DownloadService;
import androidx.media3.exoplayer.scheduler.PlatformScheduler;
import androidx.media3.exoplayer.scheduler.Scheduler;

import com.hamburghini.playerplus.R;

import java.util.List;

@OptIn(markerClass = UnstableApi.class)
public abstract class PlayerDownloadService extends DownloadService {

    private static final int FOREGROUND_NOTIFICATION_ID = 1;
    private static final String DOWNLOAD_NOTIFICATION_CHANNEL_ID = "player_plus_downloads";
    private static final int JOB_ID = 1;

    public PlayerDownloadService() {
        super(
                FOREGROUND_NOTIFICATION_ID,
                DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
                DOWNLOAD_NOTIFICATION_CHANNEL_ID,
                R.string.download_notification_channel_name,
                R.string.download_notification_channel_description
        );
    }

    @Override
    protected androidx.media3.exoplayer.offline.DownloadManager getDownloadManager() {
        return DownloadManager.getInstance(this).media3DownloadManager;
    }

    @Override
    protected Scheduler getScheduler() {
        return new PlatformScheduler(this, JOB_ID);
    }

    @Override
    protected Notification getForegroundNotification(
            List<Download> downloads,
            int notMetRequirements
    ) {
        int downloadingCount = 0;
        for (Download download : downloads) {
            if (download.state == Download.STATE_DOWNLOADING) {
                downloadingCount++;
            }
        }

        String title;
        if (downloadingCount > 0) {
            title = "Downloading " + downloadingCount + " video(s)";
        } else {
            boolean hasCompleted = false;
            for (Download download : downloads) {
                if (download.state == Download.STATE_COMPLETED) {
                    hasCompleted = true;
                    break;
                }
            }
            title = hasCompleted ? "Downloads complete" : "Player+ Downloads";
        }

        float totalProgress = 0f;
        for (Download download : downloads) {
            if (download.state == Download.STATE_DOWNLOADING) {
                totalProgress += download.getPercentDownloaded();
            }
        }
        int avgProgress = downloadingCount > 0 ? (int) (totalProgress / downloadingCount) : 0;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, DOWNLOAD_NOTIFICATION_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(downloadingCount > 0 ? avgProgress + "% complete" : "")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW);

        if (downloadingCount > 0) {
            builder.setProgress(100, avgProgress, false);
        }

        return builder.build();
    }
}