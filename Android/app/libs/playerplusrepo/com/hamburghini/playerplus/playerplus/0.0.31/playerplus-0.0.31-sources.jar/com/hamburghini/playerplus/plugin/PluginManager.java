package com.hamburghini.playerplus.plugin;

import android.content.Context;

import com.hamburghini.playerplus.SDKLogger;

import java.util.ArrayList;
import java.util.List;

public class PluginManager {

    private final List<Plugin> plugins = new ArrayList<>();
    private final Context context;

    public PluginManager(Context context) {
        this.context = context;
    }

    public void register(Plugin plugin) {
        if (plugins.contains(plugin)) {
            SDKLogger.w("Plugin already registered: " + plugin.getName());
            return;
        }
        plugins.add(plugin);
        plugin.onRegister(context);
    }

    public void unregister(Plugin plugin) {
        if (plugins.remove(plugin)) {
            plugin.onUnregister();
            SDKLogger.i("Plugin unregistered: " + plugin.getName());
        }
    }

    public <T> T findPlugin(Class<T> clazz) {
        for (Plugin plugin : plugins) {
            if (clazz.isInstance(plugin)) {
                return clazz.cast(plugin);
            }
        }
        return null;
    }

    public <T> T getCapability(Class<T> type) {
        for (Plugin p : plugins) {
            if (type.isInstance(p)) {
                return type.cast(p);
            }
        }
        return null;
    }
}
