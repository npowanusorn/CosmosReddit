package com.hamburghini.playerplus.download;

import android.content.Context;

import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.cache.CacheDataSource;
import androidx.media3.datasource.cache.NoOpCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.exoplayer.scheduler.Requirements;

import com.hamburghini.playerplus.SDKLogger;

import java.io.File;
import java.util.concurrent.Executors;

/**
 * Internal download manager - wraps Media3's DownloadManager
 * Users should interact with Downloader instead
 */
@OptIn(markerClass = UnstableApi.class)
class DownloadManager {

    private static final String DOWNLOAD_CONTENT_DIRECTORY = "player_plus_downloads";

    private static volatile DownloadManager instance;

    private final Context appContext;
    private final File downloadDirectory;
    private final SimpleCache downloadCache;
    private final DataSource.Factory httpDataSourceFactory;
    private final DataSource.Factory cacheDataSourceFactory;
    final androidx.media3.exoplayer.offline.DownloadManager media3DownloadManager;

    private DownloadManager(Context context) {
        this.appContext = context.getApplicationContext();

        // Setup download directory
        File externalFilesDir = appContext.getExternalFilesDir(null);
        this.downloadDirectory = externalFilesDir != null ? externalFilesDir : appContext.getFilesDir();
        File downloadContentDirectory = new File(downloadDirectory, DOWNLOAD_CONTENT_DIRECTORY);

        // Setup database
        StandaloneDatabaseProvider databaseProvider = new StandaloneDatabaseProvider(appContext);

        // Setup cache
        this.downloadCache = new SimpleCache(
                downloadContentDirectory,
                new NoOpCacheEvictor(),
                databaseProvider
        );

        // Setup data sources
        this.httpDataSourceFactory = new DefaultHttpDataSource.Factory();

        DefaultDataSource.Factory upstreamFactory = new DefaultDataSource.Factory(appContext, httpDataSourceFactory);
        this.cacheDataSourceFactory = new CacheDataSource.Factory()
                .setCache(downloadCache)
                .setUpstreamDataSourceFactory(upstreamFactory)
                .setCacheWriteDataSinkFactory(null)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR);

        // Setup download manager
        this.media3DownloadManager = new androidx.media3.exoplayer.offline.DownloadManager(
                appContext,
                databaseProvider,
                downloadCache,
                httpDataSourceFactory,
                Executors.newFixedThreadPool(10)
        );

        media3DownloadManager.setMaxParallelDownloads(3);

        SDKLogger.i("DownloadManager initialized");
    }

    static DownloadManager getInstance(Context context) {
        if (instance == null) {
            synchronized (DownloadManager.class) {
                if (instance == null) {
                    instance = new DownloadManager(context);
                }
            }
        }
        return instance;
    }

    void pauseDownloads() {
        media3DownloadManager.pauseDownloads();
    }

    void resumeDownloads() {
        media3DownloadManager.resumeDownloads();
    }

    DataSource.Factory getDataSourceFactory() {
        return cacheDataSourceFactory;
    }

    int getRequirements() {
        return media3DownloadManager.getRequirements().getRequirements();
    }

    void setRequirements(int requirements) {
        media3DownloadManager.setRequirements(new Requirements(requirements));
    }

    void release() {
        media3DownloadManager.release();
        downloadCache.release();
        SDKLogger.i("DownloadManager released");
    }
}