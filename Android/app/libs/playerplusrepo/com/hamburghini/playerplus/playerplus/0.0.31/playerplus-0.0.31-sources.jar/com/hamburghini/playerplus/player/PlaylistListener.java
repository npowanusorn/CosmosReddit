package com.hamburghini.playerplus.player;

import com.hamburghini.playerplus.player.configs.PlayerConfig;

public interface PlaylistListener {
    void onItemChanged(PlayerConfig config);
    void onPlaylistEnded();
}
