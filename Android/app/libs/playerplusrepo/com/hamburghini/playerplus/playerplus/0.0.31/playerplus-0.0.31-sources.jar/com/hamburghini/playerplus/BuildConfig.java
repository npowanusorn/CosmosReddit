/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.hamburghini.playerplus;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.hamburghini.playerplus";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String LIBRARY_VERSION = "0.0.31";
}
