package com.hamburghini.playerplus.player;

import androidx.media3.common.PlaybackException;
import androidx.media3.common.VideoSize;

import com.hamburghini.playerplus.exceptions.PlayerPlusException;

public interface PlayerListener {
    void onPlaybackStateChanged(PlayerController.State state);
    void onPlayerError(PlayerPlusException error);
    void onIsPlayingChanged(boolean isPlaying);
    void onVolumeChanged(float volume);
    void onDeviceVolumeChanged(int volume, boolean muted);
    void onVideoSizeChanged(VideoSize videoSize);
}