package com.hamburghini.playerplus.capabilities;

import androidx.media3.datasource.HttpDataSource;

public interface CdnTrackingCapability {
    HttpDataSource.Factory createDataSourceFactory();
}
