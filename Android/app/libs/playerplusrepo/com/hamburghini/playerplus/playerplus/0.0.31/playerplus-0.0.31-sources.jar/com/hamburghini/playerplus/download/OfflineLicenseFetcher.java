package com.hamburghini.playerplus.download;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.OptIn;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.drm.DrmSession;
import androidx.media3.exoplayer.drm.DrmSessionEventListener;
import androidx.media3.exoplayer.drm.OfflineLicenseHelper;

import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.player.DrmScheme;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@OptIn(markerClass = UnstableApi.class)
class OfflineLicenseFetcher {

    /**
     * Callback interface for license fetch results
     */
    public interface Callback {
        /**
         * Called when license is successfully fetched
         * @param keySetId The license key set ID to be used for offline playback
         */
        void onLicenseFetched(byte[] keySetId);

        /**
         * Called when license fetch fails
         * @param error The exception that caused the failure
         */
        void onLicenseFetchError(Exception error);
    }

    private final Format format;
    private final MediaItem.DrmConfiguration drmConfiguration;
    private final DataSource.Factory dataSourceFactory;
    private final Callback callback;

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Future<?> future;

    private byte[] keySetId;
    private DrmSession.DrmSessionException drmSessionException;

    public OfflineLicenseFetcher(
            Format format,
            MediaItem.DrmConfiguration drmConfiguration,
            DataSource.Factory dataSourceFactory,
            Callback callback
    ) {
        this.format = format;
        this.drmConfiguration = drmConfiguration;
        this.dataSourceFactory = dataSourceFactory;
        this.callback = callback;

        // Verify that the DRM scheme is Widevine
        if (!drmConfiguration.scheme.equals(C.WIDEVINE_UUID)) {
            throw new IllegalArgumentException("Only Widevine DRM is supported for offline license fetching");
        }
    }

    /**
     * Execute the license fetch operation
     * This is an asynchronous operation that will callback on the main thread
     */
    public void execute() {
        SDKLogger.d("Starting offline license fetch for format: " + format.id);

        future = executorService.submit(() -> {
            OfflineLicenseHelper offlineLicenseHelper = null;

            try {
                // Create offline license helper
                offlineLicenseHelper = OfflineLicenseHelper.newWidevineInstance(
                        drmConfiguration.licenseUri.toString(),
                        drmConfiguration.forceDefaultLicenseUri,
                        dataSourceFactory,
                        drmConfiguration.licenseRequestHeaders,
                        new DrmSessionEventListener.EventDispatcher()
                );

                // Download the license
                SDKLogger.d("Downloading Widevine license...");
                keySetId = offlineLicenseHelper.downloadLicense(format);
                SDKLogger.i("Offline license fetched successfully");

            } catch (DrmSession.DrmSessionException e) {
                SDKLogger.e("Failed to fetch offline license", e);
                drmSessionException = e;

            } finally {
                if (offlineLicenseHelper != null) {
                    offlineLicenseHelper.release();
                }

                final byte[] finalKeySetId = keySetId;
                final DrmSession.DrmSessionException finalException = drmSessionException;

                mainHandler.post(() -> {
                    if (finalException != null) {
                        callback.onLicenseFetchError(finalException);
                    } else {
                        if (finalKeySetId == null) {
                            callback.onLicenseFetchError(new IllegalStateException("KeySetId is null"));
                        } else {
                            callback.onLicenseFetched(finalKeySetId);
                        }
                    }
                });
            }
        });
    }

    /**
     * Cancel the ongoing license fetch operation
     */
    public void cancel() {
        SDKLogger.d("Cancelling offline license fetch");
        if (future != null) {
            future.cancel(false);
        }
    }

    /**
     * Release resources
     */
    public void release() {
        cancel();
        executorService.shutdown();
    }

    /**
     * Check if a DRM scheme supports offline licenses
     */
    public static boolean supportsOfflineLicense(DrmScheme drmScheme) {
        return drmScheme == DrmScheme.WIDEVINE;
    }

    /**
     * Release an offline license
     * Call this when removing a download to clean up the license
     *
     * @param keySetId The key set ID of the license to release
     * @param drmConfiguration The DRM configuration
     * @param dataSourceFactory Data source factory for network requests
     */
    public static void releaseLicense(
            byte[] keySetId,
            MediaItem.DrmConfiguration drmConfiguration,
            DataSource.Factory dataSourceFactory
    ) {
        try {
            OfflineLicenseHelper offlineLicenseHelper = OfflineLicenseHelper.newWidevineInstance(
                    drmConfiguration.licenseUri.toString(),
                    drmConfiguration.forceDefaultLicenseUri,
                    dataSourceFactory,
                    drmConfiguration.licenseRequestHeaders,
                    new DrmSessionEventListener.EventDispatcher()
            );

            offlineLicenseHelper.releaseLicense(keySetId);
            offlineLicenseHelper.release();

            SDKLogger.i("Offline license released");
        } catch (Exception e) {
            SDKLogger.e("Failed to release offline license", e);
        }
    }

    /**
     * Renew an offline license
     * Call this periodically to keep the license valid
     *
     * @param keySetId The key set ID of the license to renew
     * @param drmConfiguration The DRM configuration
     * @param dataSourceFactory Data source factory for network requests
     * @return New key set ID or null if renewal failed
     */
    public static byte[] renewLicense(
            byte[] keySetId,
            MediaItem.DrmConfiguration drmConfiguration,
            DataSource.Factory dataSourceFactory
    ) {
        try {
            OfflineLicenseHelper offlineLicenseHelper = OfflineLicenseHelper.newWidevineInstance(
                    drmConfiguration.licenseUri.toString(),
                    drmConfiguration.forceDefaultLicenseUri,
                    dataSourceFactory,
                    drmConfiguration.licenseRequestHeaders,
                    new DrmSessionEventListener.EventDispatcher()
            );

            byte[] newKeySetId = offlineLicenseHelper.renewLicense(keySetId);
            offlineLicenseHelper.release();

            SDKLogger.i("Offline license renewed");
            return newKeySetId;
        } catch (Exception e) {
            SDKLogger.e("Failed to renew offline license", e);
            return null;
        }
    }
}