package com.hamburghini.playerplus.player;

import android.content.Context;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;

import com.hamburghini.playerplus.SDKLogger;
import com.hamburghini.playerplus.player.configs.PlayerConfig;

import java.util.ArrayList;
import java.util.List;

@OptIn(markerClass = UnstableApi.class)
public class PlaylistController extends PlayerController {

    private PlaylistListener playlistListener;
    private final List<PlayerConfig> playlistConfigs = new ArrayList<>();
    private RepeatMode currentRepeatMode = RepeatMode.OFF;

    public PlaylistController(Context context) {
        super(context);

        // Add listener for media item transitions
        getPlayer().addListener(new Player.Listener() {
            @Override
            public void onMediaItemTransition(MediaItem mediaItem, int reason) {
                if (mediaItem != null) {
                    int currentIndex = getPlayer().getCurrentMediaItemIndex();
                    if (currentIndex >= 0 && currentIndex < playlistConfigs.size()) {
                        if (playlistListener != null) {
                            playlistListener.onItemChanged(playlistConfigs.get(currentIndex));
                        }
                    }
                }
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_ENDED) {
                    if (playlistListener != null) {
                        playlistListener.onPlaylistEnded();
                    }
                }
            }
        });
    }

    /**
     * Add a playlist listener
     */
    public void addPlaylistListener(PlaylistListener listener) {
        this.playlistListener = listener;
    }

    /**
     * Open a playlist of videos
     * @param configs List of PlayerConfig items to play
     */
    public void open(List<PlayerConfig> configs) {
        if (configs.isEmpty()) {
            return;
        }

        playerConfig = !configs.isEmpty() ? configs.get(0) : null;
        playlistConfigs.clear();
        playlistConfigs.addAll(configs);

        List<MediaItem> mediaItems = new ArrayList<>();
        for (PlayerConfig config : configs) {
            mediaItems.add(SDKUtils.buildMediaItem(config));
        }

        getPlayer().setMediaItems(mediaItems);
        getPlayer().prepare();

        boolean playWhenReady = !configs.isEmpty() && configs.get(0).isPlayWhenReady();
        getPlayer().setPlayWhenReady(playWhenReady);

        if (!configs.isEmpty() && playlistListener != null) {
            playlistListener.onItemChanged(configs.get(0));
        }
    }

    /**
     * Add an item to the end of the playlist
     */
    public void add(PlayerConfig config) {
        SDKLogger.d("Adding item to playlist");
        playlistConfigs.add(config);
        getPlayer().addMediaItem(SDKUtils.buildMediaItem(config));
    }

    /**
     * Insert an item at a specific position
     */
    public void insert(int index, PlayerConfig config) {
        SDKLogger.d("Inserting item at index " + index);
        playlistConfigs.add(index, config);
        getPlayer().addMediaItem(index, SDKUtils.buildMediaItem(config));
    }

    /**
     * Remove an item from the playlist
     */
    public void remove(int index) {
        if (index >= 0 && index < playlistConfigs.size()) {
            SDKLogger.d("Removing item at index " + index);
            playlistConfigs.remove(index);
            getPlayer().removeMediaItem(index);
        }
    }

    /**
     * Move to the next item in the playlist
     */
    public void next() {
        if (hasNext()) {
            getPlayer().seekToNextMediaItem();
        }
    }

    /**
     * Move to the previous item in the playlist
     */
    public void previous() {
        if (hasPrevious()) {
            getPlayer().seekToPreviousMediaItem();
        }
    }

    /**
     * Check if there is a next item
     */
    public boolean hasNext() {
        return getPlayer().hasNextMediaItem();
    }

    /**
     * Check if there is a previous item
     */
    public boolean hasPrevious() {
        return getPlayer().hasPreviousMediaItem();
    }

    /**
     * Seek to a specific playlist item
     */
    public void seekToItem(int index) {
        if (index >= 0 && index < playlistConfigs.size()) {
            SDKLogger.d("Seeking to item at index " + index);
            getPlayer().seekToDefaultPosition(index);
        }
    }

    /**
     * Get the current item index
     */
    public int getCurrentItemIndex() {
        return getPlayer().getCurrentMediaItemIndex();
    }

    /**
     * Get the total number of items in the playlist
     */
    public int getPlaylistSize() {
        return playlistConfigs.size();
    }

    /**
     * Get the current item config
     */
    public PlayerConfig getCurrentItemConfig() {
        int index = getCurrentItemIndex();
        if (index >= 0 && index < playlistConfigs.size()) {
            return playlistConfigs.get(index);
        }
        return null;
    }

    /**
     * Get all playlist configs
     */
    public List<PlayerConfig> getPlaylistConfigs() {
        return new ArrayList<>(playlistConfigs);
    }

    /**
     * Set repeat mode for the playlist
     */
//    public void setRepeatMode(RepeatMode mode) {
//        SDKLogger.d("Setting repeat mode to " + mode);
//        currentRepeatMode = mode;
//        getPlayer().setRepeatMode(mode.getValue());
//    }

    /**
     * Get current repeat mode
     */
    public RepeatMode getRepeatMode() {
        return currentRepeatMode;
    }

    /**
     * Clear the entire playlist
     */
    public void clearPlaylist() {
        SDKLogger.d("Clearing playlist");
        playlistConfigs.clear();
        getPlayer().clearMediaItems();
    }

    /**
     * Enable shuffle mode
     */
    public void setShuffleModeEnabled(boolean enabled) {
        SDKLogger.d("Setting shuffle mode to " + enabled);
        getPlayer().setShuffleModeEnabled(enabled);
    }

    /**
     * Check if shuffle mode is enabled
     */
    public boolean isShuffleModeEnabled() {
        return getPlayer().getShuffleModeEnabled();
    }

    @Override
    public void release() {
        playlistConfigs.clear();
        playlistListener = null;
        super.release();
    }
}