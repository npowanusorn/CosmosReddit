package com.hamburghini.playerplus.download;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.offline.DownloadHelper;

import com.hamburghini.playerplus.player.configs.DrmConfig;
import com.hamburghini.playerplus.player.models.AudioTrack;
import com.hamburghini.playerplus.player.models.VideoTrack;
import com.hamburghini.playerplus.SDKLogger;

@OptIn(markerClass = UnstableApi.class)
public class DownloadModel {

    private final String id;
    private final String contentUrl;
    private final VideoTrack[] videoTracks;
    private final AudioTrack[] audioTracks;
    private final String thumbnailPath;
    private final DownloadHelper downloadHelper;
    private final DrmConfig drmConfig;
    private final byte[] data;

    private int selectedVideoTrack;
    private int[] selectedAudioTracks;

    DownloadModel(
            String id,
            String contentUrl,
            VideoTrack[] videoTracks,
            AudioTrack[] audioTracks,
            String thumbnailPath,
            DownloadHelper downloadHelper,
            DrmConfig drmConfig,
            byte[] data
    ) {
        this.id = id;
        this.contentUrl = contentUrl;
        this.videoTracks = videoTracks;
        this.audioTracks = audioTracks;
        this.thumbnailPath = thumbnailPath;
        this.downloadHelper = downloadHelper;
        this.drmConfig = drmConfig;
        this.data = data;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getContentUrl() {
        return contentUrl;
    }

    public VideoTrack[] getVideoTracks() {
        return videoTracks;
    }

    public AudioTrack[] getAudioTracks() {
        return audioTracks;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }

    public boolean hasThumbnail() {
        return thumbnailPath != null;
    }

    DownloadHelper getDownloadHelper() {
        return downloadHelper;
    }

    public byte[] getData() {
        return data;
    }

    /**
     * Check if this is a progressive download (MP4, etc.)
     * Progressive downloads don't have track selection
     */
    public boolean isProgressiveDownload() {
        return downloadHelper == null;
    }

    /**
     * Check if this is an adaptive streaming download (DASH, HLS)
     * Adaptive downloads support track selection
     */
    public boolean isAdaptiveDownload() {
        return downloadHelper != null;
    }

    // Track selection
    public int getSelectedVideoTrack() {
        return selectedVideoTrack;
    }

    public void setSelectedVideoTrack(int index) {
        if (isProgressiveDownload()) {
            SDKLogger.w("Cannot select video track for progressive download");
            return;
        }
        if (index < 0 || index >= videoTracks.length) {
            throw new IndexOutOfBoundsException("Invalid video track index: " + index);
        }
        this.selectedVideoTrack = index;
    }

    @Nullable
    public int[] getSelectedAudioTracks() {
        return selectedAudioTracks;
    }

    public void setSelectedAudioTracks(int[] tracks) {
        if (isProgressiveDownload()) {
            SDKLogger.w("Cannot select audio tracks for progressive download");
            return;
        }
        for (int index : tracks) {
            if (index < 0 || index >= audioTracks.length) {
                throw new IndexOutOfBoundsException("Invalid audio track index: " + index);
            }
        }
        this.selectedAudioTracks = tracks;
    }

    // DRM
    @Nullable
    public DrmConfig getDrmConfig() {
        return drmConfig;
    }

    public boolean hasDrm() {
        return drmConfig != null;
    }

    @NonNull
    @Override
    public String toString() {
        return "DownloadModel{" +
                "id='" + id + '\'' +
                ", contentUrl='" + contentUrl + '\'' +
                ", videoTracks=" + videoTracks.length +
                ", audioTracks=" + audioTracks.length +
                ", drmConfig=" + drmConfig +
                '}';
    }
}